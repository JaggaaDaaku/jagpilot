// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

using UnrealBuildTool;

public class JagPilot : ModuleRules
{
	public JagPilot(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.AddRange(
			new string[] {
			}
		);

		PrivateIncludePaths.AddRange(
			new string[] {
			}
		);

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"EditorSubsystem",
				"DeveloperSettings",
				"Projects"
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"UnrealEd",
				"Slate",
				"SlateCore",
				"InputCore",
				"ToolMenus",
				"LevelEditor",
				"HTTPServer",
				"WebSockets",
				"Sockets",
				"Networking",
				"HTTP",
				"Json",
				"JsonUtilities",
				"WebBrowser",
				"ApplicationCore",
				"AssetRegistry",
				"Kismet",
				"KismetCompiler",
				"BlueprintGraph",
				"EditorScriptingUtilities",
				"ImageWrapper",
				"LiveCoding",
				"InterchangeCore",
				"InterchangeEngine"
			}
		);

		DynamicallyLoadedModuleNames.AddRange(
			new string[] {
			}
		);
	}
}
