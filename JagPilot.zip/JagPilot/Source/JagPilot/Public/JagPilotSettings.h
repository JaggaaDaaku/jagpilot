// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "JagPilotSettings.generated.h"

/**
 * UJagPilotSettings
 * Global project settings for JagPilot AI Copilot in Unreal Editor Project Settings.
 */
UCLASS(config = Editor, defaultconfig, meta = (DisplayName = "JagPilot AI"))
class JAGPILOT_API UJagPilotSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UJagPilotSettings();

	/** Section header name in Project Settings */
	virtual FName GetContainerName() const override { return "Editor"; }
	virtual FName GetCategoryName() const override { return "Plugins"; }
	virtual FName GetSectionName() const override { return "JagPilot"; }

	// --- Server Configuration ---

	/** Port for the in-engine MCP JSON-RPC Server */
	UPROPERTY(config, EditAnywhere, Category = "Server", meta = (ClampMin = "1024", ClampMax = "65535"))
	int32 ServerPort;

	/** Automatically start the MCP server when Unreal Editor launches */
	UPROPERTY(config, EditAnywhere, Category = "Server")
	bool bAutoStartServer;

	// --- Zero-Dollar Cloud Brain ---

	/** Google Gemini API Key from Google AI Studio (Zero-dollar Flash free tier) */
	UPROPERTY(config, EditAnywhere, Category = "Cloud Brain (Gemini)", meta = (PasswordField = true))
	FString GeminiApiKey;

	/** Selected Gemini model for code and Blueprint synthesis */
	UPROPERTY(config, EditAnywhere, Category = "Cloud Brain (Gemini)")
	FString PrimaryModel;

	// --- Local Unified ComfyUI Pipeline ---

	/** Local ComfyUI host address */
	UPROPERTY(config, EditAnywhere, Category = "Local ComfyUI")
	FString ComfyUIHost;

	/** Local ComfyUI port (Default: 8002) */
	UPROPERTY(config, EditAnywhere, Category = "Local ComfyUI", meta = (ClampMin = "1024", ClampMax = "65535"))
	int32 ComfyUIPort;

	/** Enable VRAM Arbitrator to throttle editor viewport rendering during 3D/Texture generation */
	UPROPERTY(config, EditAnywhere, Category = "Hardware (RTX 3070 8GB)")
	bool bEnableVRAMArbitrator;

	/** Target triangle budget for Asset Studio mesh decimation */
	UPROPERTY(config, EditAnywhere, Category = "3D Generation", meta = (ClampMin = "1000", ClampMax = "100000"))
	int32 TargetTriangleBudget;
};

