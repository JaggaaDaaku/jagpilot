// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"
#include "IWebSocket.h"
#include "Engine/Texture2D.h"
#include "JagPilotComfyBridge.generated.h"

DECLARE_DELEGATE_TwoParams(FOnComfyWorkflowCompleted, bool /*bSuccess*/, const FString& /*OutputFilePath*/);
DECLARE_DELEGATE_TwoParams(FOnComfyProgressUpdate, int32 /*CurrentStep*/, int32 /*TotalSteps*/);

/**
 * UJagPilotComfyBridge
 * Native C++ bridge connecting Unreal Engine directly to local ComfyUI on port 8002 (http://127.0.0.1:8002).
 * Manages WebSocket event streams, workflow submission, automated VRAM arbitration,
 * and direct binary texture/mesh importing into Unreal Engine packages.
 */
UCLASS()
class JAGPILOT_API UJagPilotComfyBridge : public UObject
{
	GENERATED_BODY()

public:
	UJagPilotComfyBridge();

	/** Initializes bridge and attempts WebSocket connection */
	void Initialize();

	/** Disconnects and cleans up WebSocket */
	void Shutdown();

	/** Submits a raw workflow JSON object to ComfyUI with automatic VRAM arbitration */
	void ExecuteWorkflow(
		const TSharedPtr<FJsonObject>& WorkflowJson,
		const FOnComfyWorkflowCompleted& OnComplete,
		const FOnComfyProgressUpdate& OnProgress = FOnComfyProgressUpdate()
	);

	/** Generates a 3D Mesh using local Trellis 2 INT8 / Hunyuan3D v2.1 models */
	void Generate3DMesh(
		const FString& Prompt,
		int32 TriangleBudget,
		const FOnComfyWorkflowCompleted& OnComplete
	);

	/** Generates PBR Normal and Curvature textures using MoGe 2 Vit-L Normal */
	void GeneratePBRTextures(
		const FString& InputImageOrPrompt,
		const FOnComfyWorkflowCompleted& OnComplete
	);

	/** Generates procedural sound effect / UI audio using Stable Audio Open */
	void GenerateSoundEffect(
		const FString& AudioPrompt,
		float DurationSeconds,
		const FOnComfyWorkflowCompleted& OnComplete
	);

	/** Downloads an image from ComfyUI /view?filename= and imports it as a UTexture2D asset */
	void DownloadAndImportTexture(
		const FString& Filename,
		const FString& TargetPackagePath,
		TFunction<void(UTexture2D*)> OnImported
	);

	/** Returns normalized base URL (Default: http://127.0.0.1:8002) */
	FString GetBaseUrl() const;

	/** Normalizes URL input string ensuring correct protocol and port */
	static FString NormalizeComfyUrl(const FString& InUrl);

	/** Returns true if ComfyUI is currently executing a task */
	bool IsBusy() const { return bIsExecuting; }

	/** Returns true if connected to ComfyUI WebSocket */
	bool IsConnected() const;

private:
	void ConnectWebSocket();
	void OnWebSocketMessage(const FString& Message);
	void OnWebSocketConnected();
	void OnWebSocketError(const FString& Error);
	void OnWebSocketClosed(int32 StatusCode, const FString& Reason, bool bWasClean);

	FString ClientId;
	TSharedPtr<IWebSocket> WebSocket;
	bool bIsExecuting;
	FString CurrentPromptId;
	FOnComfyWorkflowCompleted ActiveCompletionCallback;
	FOnComfyProgressUpdate ActiveProgressCallback;
};
