// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogJagPilot, Log, All);

class FJagPilotModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	/** Returns the singleton module instance */
	static inline FJagPilotModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FJagPilotModule>("JagPilot");
	}

	/** Returns true if the module is loaded */
	static inline bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded("JagPilot");
	}
};

