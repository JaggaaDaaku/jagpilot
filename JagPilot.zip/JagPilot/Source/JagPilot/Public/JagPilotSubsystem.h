// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "JagPilotSubsystem.generated.h"

class FLevelEditorViewportClient;
class FJagPilotServer;
class UJagPilotToolRegistry;
class UJagPilotModelRouter;
class UJagPilotComfyBridge;

/**
 * UJagPilotSubsystem
 * Core Editor Subsystem managing the JagPilot AI Copilot lifecycle, VRAM Arbitrator,
 * embedded MCP JSON-RPC Server, and local/cloud Model Routers.
 */
UCLASS()
class JAGPILOT_API UJagPilotSubsystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	UJagPilotSubsystem();

	// USubsystem lifecycle overrides
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	/**
	 * VRAM Arbitrator: Prepares the editor for heavy generative AI workloads (ComfyUI / 3D synthesis).
	 * Pauses viewport realtime rendering and trims GPU memory caches to free ~2.3GB VRAM for the RTX 3070.
	 */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|VRAM")
	void BeginGenerativeAITask();

	/**
	 * VRAM Arbitrator: Restores editor viewport rendering state after generative AI task finishes.
	 */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|VRAM")
	void EndGenerativeAITask();

	/** Starts the in-engine MCP server */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Server")
	bool StartMCPServer();

	/** Stops the in-engine MCP server */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Server")
	void StopMCPServer();

	/** Returns true if a generative AI task is currently holding throttled VRAM state */
	UFUNCTION(BlueprintPure, Category = "JagPilot|VRAM")
	bool IsGenerativeTaskRunning() const { return bIsGenerativeTaskActive; }

	/** Returns true if the subsystem and all dependent subsystems are safely initialized */
	UFUNCTION(BlueprintPure, Category = "JagPilot")
	bool IsReady() const { return bIsInitialized; }

	/** Returns the dynamic MCP tool registry */
	UFUNCTION(BlueprintPure, Category = "JagPilot")
	UJagPilotToolRegistry* GetToolRegistry() const { return ToolRegistry; }

	/** Returns the Zero-Dollar model router */
	UFUNCTION(BlueprintPure, Category = "JagPilot")
	UJagPilotModelRouter* GetModelRouter() const { return ModelRouter; }

	/** Returns the local ComfyUI bridge */
	UFUNCTION(BlueprintPure, Category = "JagPilot")
	UJagPilotComfyBridge* GetComfyBridge() const { return ComfyBridge; }

private:
	/** Finds the active Level Editor viewport client */
	FLevelEditorViewportClient* GetActiveLevelViewportClient() const;

	/** Subsystem instances */
	TSharedPtr<FJagPilotServer> MCPServer;

	UPROPERTY()
	TObjectPtr<UJagPilotToolRegistry> ToolRegistry;

	UPROPERTY()
	TObjectPtr<UJagPilotModelRouter> ModelRouter;

	UPROPERTY()
	TObjectPtr<UJagPilotComfyBridge> ComfyBridge;

	/** State tracking */
	bool bIsInitialized;
	bool bIsGenerativeTaskActive;
	bool bPreviousViewportRealtimeState;
};
