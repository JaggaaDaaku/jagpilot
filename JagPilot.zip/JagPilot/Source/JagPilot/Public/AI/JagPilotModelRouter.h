// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"
#include "Interfaces/IHttpRequest.h"
#include "JagPilotModelRouter.generated.h"

class UJagPilotToolRegistry;

DECLARE_DELEGATE_TwoParams(FOnModelResponseReceived, bool /*bSuccess*/, const FString& /*ResponseText*/);

/**
 * UJagPilotModelRouter
 * Direct Zero-Dollar AI Model Router.
 * Supports:
 * - Google Gemini Zero-Dollar Lineup (3.8 Flash, 3.6 Flash, 3.5 Flash-Lite, Gemma 4) via Google AI Studio API
 * - Cloud Free Endpoints (deepseek-v4.1-flash, glm-5.3-flash, kimi-k3)
 * - Local ComfyUI VLM/NLP text inference
 */
UCLASS()
class JAGPILOT_API UJagPilotModelRouter : public UObject
{
	GENERATED_BODY()

public:
	UJagPilotModelRouter();

	/** Initializes the router with reference to the Tool Registry */
	void Initialize(UJagPilotToolRegistry* InToolRegistry);

	/**
	 * Sends a prompt with full tool awareness to the selected model backend.
	 * Executes tool calls automatically on the Unreal GameThread.
	 */
	void SendPrompt(
		const FString& ModelName,
		const FString& SystemInstruction,
		const FString& UserPrompt,
		const FOnModelResponseReceived& OnResponse
	);

	/** Returns available model options categorized for the UI selector dropdown */
	TSharedPtr<FJsonObject> GetAvailableModelsList() const;

private:
	/** Google Gemini REST endpoint implementation */
	void DispatchComfyUIRequest(
		const FString& ModelName,
		const FString& UserPrompt,
		const FOnModelResponseReceived& OnResponse
	);

	void DispatchGeminiRequest(
		const FString& ModelName,
		const FString& SystemInstruction,
		const FString& UserPrompt,
		const FOnModelResponseReceived& OnResponse
	);

	/** Handles Gemini HTTP Response and auto-executes function calls */
	void HandleGeminiResponse(
		FHttpRequestPtr Request,
		FHttpResponsePtr Response,
		bool bConnectedSuccessfully,
		FString ModelName,
		FOnModelResponseReceived OnResponse
	);

	UPROPERTY()
	TWeakObjectPtr<UJagPilotToolRegistry> ToolRegistry;
};

