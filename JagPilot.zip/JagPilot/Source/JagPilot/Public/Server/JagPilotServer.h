// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "Common/TcpListener.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotServer
 * In-engine high-performance JSON-RPC 2.0 and MCP (Model Context Protocol) Server.
 * Runs on a background thread on port 8008, safely dispatching tool executions to the Unreal GameThread.
 */
class JAGPILOT_API FJagPilotServer : public FRunnable
{
public:
	FJagPilotServer(int32 InPort, UJagPilotToolRegistry* InRegistry);
	virtual ~FJagPilotServer();

	/** Starts the server background thread */
	bool Start();

	/** Stops the server safely without hanging or crashing */
	void StopServer();

	/** Returns true if server is active and listening */
	bool IsRunning() const { return bIsRunning; }

	/** Port the server is bound to */
	int32 GetPort() const { return Port; }

	// FRunnable interface
	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual void Exit() override;

private:
	/** Handles an incoming client TCP connection */
	void HandleClient(FSocket* ClientSocket);

	/** Processes raw HTTP request buffer and returns HTTP response string */
	FString ProcessHttpRequest(const FString& RawRequest);

	/** Dispatches JSON-RPC 2.0 / MCP request */
	TSharedPtr<FJsonObject> ProcessJsonRpc(const TSharedPtr<FJsonObject>& RequestObj);

	int32 Port;
	FThreadSafeBool bIsRunning;
	FRunnableThread* Thread;
	FSocket* ListenSocket;
	TWeakObjectPtr<UJagPilotToolRegistry> ToolRegistry;
};

