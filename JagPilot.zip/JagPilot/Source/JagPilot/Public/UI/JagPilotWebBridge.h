// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "JagPilotWebBridge.generated.h"

class SWebBrowser;

/**
 * UJagPilotWebBridge
 * Bidirectional C++ to JavaScript bridge for the JagPilot WebUI Canvas.
 * Bound to window.ue.jagpilot in the Chromium/CEF browser widget.
 */
UCLASS()
class JAGPILOT_API UJagPilotWebBridge : public UObject
{
	GENERATED_BODY()

public:
	UJagPilotWebBridge();

	/** Singleton access */
	static UJagPilotWebBridge* Get();

	/** Sets the active Slate Web Browser widget reference */
	void SetBrowserWidget(const TSharedPtr<SWebBrowser>& InWidget);

	// --- JavaScript Callable APIs (window.ue.jagpilot.*) ---

	/** Executes an MCP tool directly from the web canvas */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString ExecuteTool(const FString& ToolName, const FString& ArgsJson);

	/** Sends a prompt to the Zero-Dollar model router */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	void SendPrompt(const FString& ModelName, const FString& Prompt);

	/** Returns available model options for the dropdown */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString GetModelList() const;

	/** Returns active engine and VRAM status */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString GetStatus() const;

	/** Logs a message from JavaScript into UE output log */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	void Log(const FString& Message);

	/** Returns clipboard text directly from the Windows OS clipboard via Unreal Engine */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString PasteFromClipboard();

	/** Sets active backend mode */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	bool SetBackendMode(const FString& BackendMode);

	/** Gets active backend mode */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString GetBackendMode() const;

	/** Installs/imports a Fab asset pack into the project */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	bool InstallFabPack(const FString& PackName, const FString& Category);

	/** Spawns a library asset in front of the active editor camera */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	bool SpawnLibraryAsset(const FString& AssetName, const FString& Category);

	/** Persists settings JSON directly into UJagPilotSettings */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	bool SaveSettings(const FString& SettingsJson);

	/** Sets the Gemini API key into UJagPilotSettings */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	bool SetApiKey(const FString& ApiKey);

	/** Gets the stored Gemini API key */
	UFUNCTION(BlueprintCallable, Category = "JagPilot|Web")
	FString GetApiKey() const;

	/** Pushes an event asynchronously to JavaScript */
	void PushEvent(const FString& EventType, const FString& EventDataJson);

private:
	TWeakPtr<SWebBrowser> BrowserWidget;
	static UJagPilotWebBridge* Instance;
};

