// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Docking/SDockTab.h"

class SWebBrowser;
class UJagPilotWebBridge;

/**
 * FJagPilotPanel
 * Manages the dockable Nomad Tab spawner for the JagPilot WebUI Canvas in Unreal Editor.
 */
class JAGPILOT_API FJagPilotPanel
{
public:
	static const FName TabName;

	/** Registers the Nomad Tab Spawner */
	static void RegisterTab();

	/** Unregisters the Nomad Tab Spawner */
	static void UnregisterTab();

	/** Opens or focuses the JagPilot tab in the Level Editor */
	static void OpenTab();

private:
	/** Tab spawn delegate */
	static TSharedRef<SDockTab> SpawnTab(const FSpawnTabArgs& Args);

	static TSharedPtr<SWebBrowser> WebBrowserWidget;
	static UJagPilotWebBridge* WebBridge;
};

