// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"
#include "JagPilotToolRegistry.generated.h"

DECLARE_DELEGATE_RetVal_OneParam(TSharedPtr<FJsonObject>, FJagPilotToolHandler, const TSharedPtr<FJsonObject>&);

struct FJagPilotToolInfo
{
	FString Name;
	FString Description;
	FString Category;
	TSharedPtr<FJsonObject> InputSchema;
	FJagPilotToolHandler Handler;
};

/**
 * UJagPilotToolRegistry
 * Dynamic registry managing MCP tools, schemas, and GameThread dispatching.
 */
UCLASS()
class JAGPILOT_API UJagPilotToolRegistry : public UObject
{
	GENERATED_BODY()

public:
	UJagPilotToolRegistry();

	/** Initializes the default core toolset (Asset, Actor, Level, PIE) */
	void InitializeDefaultTools();

	/** Registers an MCP tool */
	void RegisterTool(const FString& Name, const FString& Description, const FString& Category, const TSharedPtr<FJsonObject>& InputSchema, const FJagPilotToolHandler& Handler);

	/** Executes a registered tool by name with arguments */
	TSharedPtr<FJsonObject> ExecuteTool(const FString& Name, const TSharedPtr<FJsonObject>& Args);

	/** Generates the full MCP tools/list JSON response */
	TSharedPtr<FJsonObject> GenerateMCPToolsList() const;

	/** Returns true if tool exists */
	bool HasTool(const FString& Name) const { return RegisteredTools.Contains(Name); }

private:
	TMap<FString, FJagPilotToolInfo> RegisteredTools;

	// Built-in tool handlers
	TSharedPtr<FJsonObject> HandleFindAssets(const TSharedPtr<FJsonObject>& Args);
	TSharedPtr<FJsonObject> HandleSpawnActor(const TSharedPtr<FJsonObject>& Args);
	TSharedPtr<FJsonObject> HandleGetSelectedActors(const TSharedPtr<FJsonObject>& Args);
	TSharedPtr<FJsonObject> HandleSetActorTransform(const TSharedPtr<FJsonObject>& Args);
	TSharedPtr<FJsonObject> HandleDeleteActor(const TSharedPtr<FJsonObject>& Args);
	TSharedPtr<FJsonObject> HandleVRAMStatus(const TSharedPtr<FJsonObject>& Args);
};

