// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotActorTools
 * Core World Authoring & Actor manipulation toolset.
 */
class JAGPILOT_API FJagPilotActorTools
{
public:
	static void RegisterTools(UJagPilotToolRegistry* Registry);

	static TSharedPtr<FJsonObject> HandleSpawnActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleTransformActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleAttachActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleDetachActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSnapToFloor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSetActorProperty(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSelectActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleDeleteActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleNormalizeAndGround(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSetupSkyLight(const TSharedPtr<FJsonObject>& Args);
};

