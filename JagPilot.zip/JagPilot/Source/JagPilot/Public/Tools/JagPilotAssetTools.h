// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotAssetTools
 * Universal reflection-based Asset Reader and Registry inspector.
 */
class JAGPILOT_API FJagPilotAssetTools
{
public:
	static void RegisterTools(UJagPilotToolRegistry* Registry);

	// Tool handlers
	static TSharedPtr<FJsonObject> HandleReadAsset(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSearchAssets(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleGetAssetReferences(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleGetDependencyTree(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleValidateAssets(const TSharedPtr<FJsonObject>& Args);

	// Reflection helper
	static TSharedPtr<FJsonObject> SerializeUObjectToJSON(UObject* Object, int32 MaxDepth = 2, int32 CurrentDepth = 0);
};

