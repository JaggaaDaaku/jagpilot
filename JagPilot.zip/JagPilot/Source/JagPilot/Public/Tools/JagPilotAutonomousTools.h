// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotAutonomousTools
 * Autonomous Execution Engines: GSD Core, Ralph Autonomous Loop,
 * Roo-Code Personas, Perpetual Memory Vault, and Live GitHub Tool Ingestion.
 */
class JAGPILOT_API FJagPilotAutonomousTools
{
public:
	static void RegisterTools(UJagPilotToolRegistry* Registry);

	// GSD Core & Ralph Loop
	static TSharedPtr<FJsonObject> HandleGSDStartTask(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleRalphStartLoop(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleRalphGetStatus(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSwitchAgentMode(const TSharedPtr<FJsonObject>& Args);

	// Perpetual Self-Improvement & Memory
	static TSharedPtr<FJsonObject> HandleLearnFromTask(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleCrystallizeSkill(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleQueryMemoryVault(const TSharedPtr<FJsonObject>& Args);

	// Live GitHub Tool Ingestion
	static TSharedPtr<FJsonObject> HandleCloneAndInspectRepo(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleSynthesizeToolWrapper(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleHotRegisterMcpTool(const TSharedPtr<FJsonObject>& Args);
};

