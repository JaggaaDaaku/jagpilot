// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotBlueprintTools
 * Graph Synthesis, Wiring, Compilation, and Self-Healing Diagnostics.
 */
class JAGPILOT_API FJagPilotBlueprintTools
{
public:
	static void RegisterTools(UJagPilotToolRegistry* Registry);

	static TSharedPtr<FJsonObject> HandleCreateBlueprint(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleCompileBlueprint(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleGetCompileErrors(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleFindUnconnectedPins(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleFixBrokenReferences(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleRefreshAllNodes(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleTriggerLiveCoding(const TSharedPtr<FJsonObject>& Args);
};

