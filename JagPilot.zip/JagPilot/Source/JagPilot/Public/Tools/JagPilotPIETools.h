// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"

class UJagPilotToolRegistry;

/**
 * FJagPilotPIETools
 * Live Play-In-Editor (PIE) Runtime Controller.
 */
class JAGPILOT_API FJagPilotPIETools
{
public:
	static void RegisterTools(UJagPilotToolRegistry* Registry);

	static TSharedPtr<FJsonObject> HandlePlayInEditor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandleStopPIE(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandlePIETeleportActor(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandlePIEConsoleCommand(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandlePIESetProperty(const TSharedPtr<FJsonObject>& Args);
	static TSharedPtr<FJsonObject> HandlePIEGetProperty(const TSharedPtr<FJsonObject>& Args);
};

