// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilotSettings.h"

UJagPilotSettings::UJagPilotSettings()
	: ServerPort(8008)
	, bAutoStartServer(true)
	, GeminiApiKey(TEXT(""))
	, PrimaryModel(TEXT("gemini-3.8-flash"))
	, ComfyUIHost(TEXT("127.0.0.1"))
	, ComfyUIPort(8002)
	, bEnableVRAMArbitrator(true)
	, TargetTriangleBudget(15000)
{
}

