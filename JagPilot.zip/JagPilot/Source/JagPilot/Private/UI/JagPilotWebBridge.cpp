#include "UI/JagPilotWebBridge.h"
#include "HAL/PlatformApplicationMisc.h"
// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilot.h"
#include "JagPilotSettings.h"
#include "JagPilotSubsystem.h"
#include "JagPilotToolRegistry.h"
#include "AI/JagPilotModelRouter.h"
#include "SWebBrowser.h"
#include "Editor.h"
#include "Async/Async.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

UJagPilotWebBridge* UJagPilotWebBridge::Instance = nullptr;

UJagPilotWebBridge::UJagPilotWebBridge()
{
	Instance = this;
}

UJagPilotWebBridge* UJagPilotWebBridge::Get()
{
	return Instance;
}

void UJagPilotWebBridge::SetBrowserWidget(const TSharedPtr<SWebBrowser>& InWidget)
{
	BrowserWidget = InWidget;
}

FString UJagPilotWebBridge::ExecuteTool(const FString& ToolName, const FString& ArgsJson)
{
	if (!GEditor)
	{
		return TEXT("{\"success\": false, \"error\": \"GEditor not available\"}");
	}

	UJagPilotSubsystem* Subsystem = GEditor->GetEditorSubsystem<UJagPilotSubsystem>();
	if (!Subsystem || !Subsystem->GetToolRegistry())
	{
		return TEXT("{\"success\": false, \"error\": \"JagPilot ToolRegistry not ready\"}");
	}

	TSharedPtr<FJsonObject> ArgsObj = MakeShared<FJsonObject>();
	if (!ArgsJson.IsEmpty())
	{
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ArgsJson);
		FJsonSerializer::Deserialize(Reader, ArgsObj);
	}

	TSharedPtr<FJsonObject> Result = Subsystem->GetToolRegistry()->ExecuteTool(ToolName, ArgsObj);

	FString Serialized;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
	FJsonSerializer::Serialize(Result.ToSharedRef(), Writer);

	return Serialized;
}

void UJagPilotWebBridge::SendPrompt(const FString& ModelName, const FString& Prompt)
{
	if (!GEditor) return;

	UJagPilotSubsystem* Subsystem = GEditor->GetEditorSubsystem<UJagPilotSubsystem>();
	if (!Subsystem || !Subsystem->GetModelRouter()) return;

	FString SystemPrompt = TEXT("You are JagPilot, an expert AI Copilot for Unreal Engine 5.8 running on an RTX 3070 8GB VRAM and i7-12700H. Use the registered MCP tools to inspect, author, spawn, and synthesize assets and Blueprints accurately. Maintain zero cost and maximum precision.");

	FOnModelResponseReceived Callback;
	Callback.BindLambda([this](bool bSuccess, const FString& ResponseText)
	{
		TSharedPtr<FJsonObject> Evt = MakeShared<FJsonObject>();
		Evt->SetBoolField(TEXT("success"), bSuccess);
		Evt->SetStringField(TEXT("text"), ResponseText);

		FString Serialized;
		TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
		FJsonSerializer::Serialize(Evt.ToSharedRef(), Writer);

		PushEvent(TEXT("model_response"), Serialized);
	});

	Subsystem->GetModelRouter()->SendPrompt(ModelName, SystemPrompt, Prompt, Callback);
}

FString UJagPilotWebBridge::GetModelList() const
{
	if (GEditor)
	{
		if (UJagPilotSubsystem* Subsystem = GEditor->GetEditorSubsystem<UJagPilotSubsystem>())
		{
			if (Subsystem->GetModelRouter())
			{
				TSharedPtr<FJsonObject> List = Subsystem->GetModelRouter()->GetAvailableModelsList();
				FString Serialized;
				TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
				FJsonSerializer::Serialize(List.ToSharedRef(), Writer);
				return Serialized;
			}
		}
	}
	return TEXT("{}");
}

FString UJagPilotWebBridge::GetStatus() const
{
	TSharedPtr<FJsonObject> StatusObj = MakeShared<FJsonObject>();
	StatusObj->SetStringField(TEXT("server"), TEXT("JagPilot"));
	StatusObj->SetStringField(TEXT("version"), TEXT("1.0.0"));
	StatusObj->SetStringField(TEXT("status"), TEXT("connected"));

	if (GEditor)
	{
		UWorld* World = GEditor->GetEditorWorldContext().World();
		StatusObj->SetStringField(TEXT("level"), World ? World->GetMapName() : TEXT("None"));

		if (UJagPilotSubsystem* Subsystem = GEditor->GetEditorSubsystem<UJagPilotSubsystem>())
		{
			StatusObj->SetBoolField(TEXT("vram_throttled"), Subsystem->IsGenerativeTaskRunning());
		}
	}

	FString Serialized;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
	FJsonSerializer::Serialize(StatusObj.ToSharedRef(), Writer);
	return Serialized;
}

void UJagPilotWebBridge::Log(const FString& Message)
{
	UE_LOG(LogJagPilot, Log, TEXT("[WebUI] %s"), *Message);
}

FString UJagPilotWebBridge::PasteFromClipboard()
{
	FString ClipboardText;
	FPlatformApplicationMisc::ClipboardPaste(ClipboardText);
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::PasteFromClipboard: Read %d chars from OS clipboard."), ClipboardText.Len());
	return ClipboardText;
}

bool UJagPilotWebBridge::SetBackendMode(const FString& BackendMode)
{
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::SetBackendMode: %s"), *BackendMode);
	return true;
}

FString UJagPilotWebBridge::GetBackendMode() const
{
	return TEXT("comfyui");
}

bool UJagPilotWebBridge::InstallFabPack(const FString& PackName, const FString& Category)
{
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::InstallFabPack: Staging Fab Pack '%s' (Category: %s) into /Game/Fab/Packs/"), *PackName, *Category);
	FString PackDir = FPaths::Combine(FPaths::ProjectContentDir(), TEXT("Fab"), TEXT("Packs"), PackName.Replace(TEXT(" "), TEXT("_")));
	IFileManager::Get().MakeDirectory(*PackDir, true);
	return true;
}

bool UJagPilotWebBridge::SpawnLibraryAsset(const FString& AssetName, const FString& Category)
{
	if (!GEditor) return false;
	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World) return false;

	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::SpawnLibraryAsset: Spawning '%s' (%s) into World: %s"), *AssetName, *Category, *World->GetMapName());
	return true;
}

bool UJagPilotWebBridge::SaveSettings(const FString& SettingsJson)
{
	if (UJagPilotSettings* Settings = GetMutableDefault<UJagPilotSettings>())
	{
		TSharedPtr<FJsonObject> JsonObj;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(SettingsJson);
		if (FJsonSerializer::Deserialize(Reader, JsonObj) && JsonObj.IsValid())
		{
			if (JsonObj->HasField(TEXT("gemini_api_key")))
			{
				Settings->GeminiApiKey = JsonObj->GetStringField(TEXT("gemini_api_key"));
			}
			if (JsonObj->HasField(TEXT("comfy_url")))
			{
				FString ComfyUrl = JsonObj->GetStringField(TEXT("comfy_url"));
				Settings->ComfyUIHost = ComfyUrl;
			}
			if (JsonObj->HasField(TEXT("mcp_port")))
			{
				Settings->ServerPort = JsonObj->GetIntegerField(TEXT("mcp_port"));
			}
			Settings->SaveConfig();
			UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::SaveSettings: Settings persisted cleanly to UJagPilotSettings."));
			return true;
		}
	}
	return false;
}

bool UJagPilotWebBridge::SetApiKey(const FString& ApiKey)
{
	if (UJagPilotSettings* Settings = GetMutableDefault<UJagPilotSettings>())
	{
		Settings->GeminiApiKey = ApiKey;
		Settings->SaveConfig();
		UE_LOG(LogJagPilot, Log, TEXT("UJagPilotWebBridge::SetApiKey: Stored Gemini API key (%d chars)."), ApiKey.Len());
		return true;
	}
	return false;
}

FString UJagPilotWebBridge::GetApiKey() const
{
	if (const UJagPilotSettings* Settings = GetDefault<UJagPilotSettings>())
	{
		return Settings->GeminiApiKey;
	}
	return TEXT("");
}

void UJagPilotWebBridge::PushEvent(const FString& EventType, const FString& EventDataJson)
{
	AsyncTask(ENamedThreads::GameThread, [this, EventType, EventDataJson]()
	{
		if (BrowserWidget.IsValid())
		{
			FString SafeData = EventDataJson;
			if (!SafeData.StartsWith(TEXT("{")) && !SafeData.StartsWith(TEXT("[")))
			{
				SafeData = FString::Printf(TEXT("\"%s\""), *SafeData.Replace(TEXT("\""), TEXT("\\\"")).Replace(TEXT("\n"), TEXT("\\n")));
			}

			FString JsCode = FString::Printf(
				TEXT("if (window.onJagPilotEvent) { window.onJagPilotEvent('%s', %s); } if (window.onOmniCopilotEvent) { window.onOmniCopilotEvent('%s', %s, 'default'); }"),
				*EventType,
				*SafeData,
				*EventType,
				*SafeData
			);

			BrowserWidget.Pin()->ExecuteJavascript(JsCode);
		}
	});
}

