// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "UI/JagPilotPanel.h"
#include "UI/JagPilotWebBridge.h"
#include "JagPilot.h"
#include "SWebBrowser.h"
#include "Framework/Docking/TabManager.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "Widgets/Docking/SDockTab.h"

const FName FJagPilotPanel::TabName = FName(TEXT("JagPilot"));
TSharedPtr<SWebBrowser> FJagPilotPanel::WebBrowserWidget = nullptr;
UJagPilotWebBridge* FJagPilotPanel::WebBridge = nullptr;

void FJagPilotPanel::RegisterTab()
{
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		TabName,
		FOnSpawnTab::CreateStatic(&FJagPilotPanel::SpawnTab)
	)
	.SetDisplayName(FText::FromString(TEXT("JagPilot")))
	.SetTooltipText(FText::FromString(TEXT("Open JagPilot AI Copilot Canvas")))
	.SetMenuType(ETabSpawnerMenuType::Enabled);

	UE_LOG(LogJagPilot, Log, TEXT("FJagPilotPanel: Nomad tab spawner registered."));
}

void FJagPilotPanel::UnregisterTab()
{
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(TabName);
	WebBrowserWidget.Reset();
	WebBridge = nullptr;
	UE_LOG(LogJagPilot, Log, TEXT("FJagPilotPanel: Nomad tab spawner unregistered cleanly."));
}

void FJagPilotPanel::OpenTab()
{
	FGlobalTabmanager::Get()->TryInvokeTab(TabName);
}

TSharedRef<SDockTab> FJagPilotPanel::SpawnTab(const FSpawnTabArgs& Args)
{
	TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("JagPilot"));
	FString ContentDir = Plugin.IsValid() ? Plugin->GetContentDir() : FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("JagPilot"), TEXT("Content"));

	FString HtmlFilePath = FPaths::Combine(ContentDir, TEXT("UI"), TEXT("index.html"));
	FString FullHtmlPath = FPaths::ConvertRelativePathToFull(HtmlFilePath);
	FString InitialUrl = FString::Printf(TEXT("file:///%s"), *FullHtmlPath.Replace(TEXT("\\"), TEXT("/")));

	WebBridge = NewObject<UJagPilotWebBridge>();

	SAssignNew(WebBrowserWidget, SWebBrowser)
		.InitialURL(InitialUrl)
		.ShowControls(false)
		.SupportsTransparency(true);

	if (WebBrowserWidget.IsValid())
	{
		WebBridge->SetBrowserWidget(WebBrowserWidget);
		WebBrowserWidget->BindUObject(TEXT("jagpilot"), WebBridge, true);
		WebBrowserWidget->BindUObject(TEXT("wingman"), WebBridge, true);
		WebBrowserWidget->BindUObject(TEXT("bridge"), WebBridge, true);
	}

	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		.Label(FText::FromString(TEXT("JagPilot")))
		[
			WebBrowserWidget.IsValid() ? WebBrowserWidget.ToSharedRef() : SNullWidget::NullWidget
		];
}

