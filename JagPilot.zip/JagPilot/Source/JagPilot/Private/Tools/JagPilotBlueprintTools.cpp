// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Tools/JagPilotBlueprintTools.h"
#include "JagPilotToolRegistry.h"
#include "JagPilot.h"
#include "Engine/Blueprint.h"
#include "GameFramework/Actor.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraphSchema_K2.h"
#include "ILiveCodingModule.h"

void FJagPilotBlueprintTools::RegisterTools(UJagPilotToolRegistry* Registry)
{
	if (!Registry) return;

	// 1. create_blueprint
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("name"), NameProp);
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		PathProp->SetStringField(TEXT("description"), TEXT("Package path (e.g. /Game/Blueprints)"));
		Props->SetObjectField(TEXT("path"), PathProp);
		TSharedPtr<FJsonObject> ParentProp = MakeShared<FJsonObject>();
		ParentProp->SetStringField(TEXT("type"), TEXT("string"));
		ParentProp->SetStringField(TEXT("description"), TEXT("Parent class name (Default: Actor)"));
		Props->SetObjectField(TEXT("parent_class"), ParentProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleCreateBlueprint);
		Registry->RegisterTool(TEXT("create_blueprint"), TEXT("Creates a new Blueprint asset with specified parent class"), TEXT("Blueprint"), Schema, Handler);
	}

	// 2. compile_blueprint
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("blueprint_path"), PathProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleCompileBlueprint);
		Registry->RegisterTool(TEXT("compile_blueprint"), TEXT("Compiles a Blueprint asset and returns compilation status"), TEXT("Blueprint"), Schema, Handler);
	}

	// 3. bp_get_compile_errors
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("blueprint_path"), PathProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleGetCompileErrors);
		Registry->RegisterTool(TEXT("bp_get_compile_errors"), TEXT("Retrieves compiler diagnostic messages, warnings, and errors for a Blueprint"), TEXT("Blueprint Debug"), Schema, Handler);
	}

	// 4. bp_find_unconnected_pins
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("blueprint_path"), PathProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleFindUnconnectedPins);
		Registry->RegisterTool(TEXT("bp_find_unconnected_pins"), TEXT("Discovers floating or unconnected execution pins across all graphs"), TEXT("Blueprint Debug"), Schema, Handler);
	}

	// 5. bp_fix_broken_references
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("blueprint_path"), PathProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleFixBrokenReferences);
		Registry->RegisterTool(TEXT("bp_fix_broken_references"), TEXT("Automated self-healing: re-links and refreshes broken node and function references"), TEXT("Blueprint Debug"), Schema, Handler);
	}

	// 6. bp_refresh_all_nodes
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PathProp = MakeShared<FJsonObject>();
		PathProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("blueprint_path"), PathProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleRefreshAllNodes);
		Registry->RegisterTool(TEXT("bp_refresh_all_nodes"), TEXT("Forces reconstruction and schema validation for all nodes in a Blueprint"), TEXT("Blueprint Debug"), Schema, Handler);
	}

	// 7. trigger_live_coding
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotBlueprintTools::HandleTriggerLiveCoding);
		Registry->RegisterTool(TEXT("trigger_live_coding"), TEXT("Triggers Unreal Engine Live Coding C++ compilation in editor"), TEXT("Blueprint Debug"), Schema, Handler);
	}
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleCreateBlueprint(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString Name = Args->GetStringField(TEXT("name"));
	FString Path = Args->HasField(TEXT("path")) ? Args->GetStringField(TEXT("path")) : TEXT("/Game/Blueprints");
	FString ParentClassName = Args->HasField(TEXT("parent_class")) ? Args->GetStringField(TEXT("parent_class")) : TEXT("Actor");

	UClass* ParentClass = UClass::TryFindTypeSlow<UClass>(ParentClassName);
	if (!ParentClass)
	{
		ParentClass = AActor::StaticClass();
	}

	FString PackagePath = FString::Printf(TEXT("%s/%s"), *Path, *Name);
	UPackage* Package = CreatePackage(*PackagePath);
	if (!Package)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Failed to create package at %s"), *PackagePath));
		return Result;
	}

	UBlueprint* NewBP = FKismetEditorUtilities::CreateBlueprint(
		ParentClass,
		Package,
		FName(*Name),
		BPTYPE_Normal,
		UBlueprint::StaticClass(),
		UEdGraphSchema_K2::StaticClass()
	);

	if (!NewBP)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("FKismetEditorUtilities::CreateBlueprint failed."));
		return Result;
	}

	Package->MarkPackageDirty();
	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("blueprint_path"), PackagePath);
	Result->SetStringField(TEXT("blueprint_name"), Name);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleCompileBlueprint(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString BlueprintPath = Args->GetStringField(TEXT("blueprint_path"));

	UBlueprint* BP = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *BlueprintPath));
	if (!BP)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Blueprint not found at %s"), *BlueprintPath));
		return Result;
	}

	FKismetEditorUtilities::CompileBlueprint(BP);

	bool bCompiledCleanly = (BP->Status == BS_UpToDate);
	Result->SetBoolField(TEXT("success"), bCompiledCleanly);
	Result->SetBoolField(TEXT("has_errors"), BP->Status == BS_Error);
	Result->SetStringField(TEXT("status"), bCompiledCleanly ? TEXT("UpToDate") : TEXT("CompileFailed"));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleGetCompileErrors(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString BlueprintPath = Args->GetStringField(TEXT("blueprint_path"));

	UBlueprint* BP = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *BlueprintPath));
	if (!BP)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Blueprint not found."));
		return Result;
	}

	TArray<TSharedPtr<FJsonValue>> Messages;
	bool bHasErrors = (BP->Status == BS_Error);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetBoolField(TEXT("has_errors"), bHasErrors);
	Result->SetArrayField(TEXT("messages"), Messages);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleFindUnconnectedPins(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString BlueprintPath = Args->GetStringField(TEXT("blueprint_path"));

	UBlueprint* BP = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *BlueprintPath));
	if (!BP)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Blueprint not found."));
		return Result;
	}

	TArray<TSharedPtr<FJsonValue>> UnconnectedList;

	for (UEdGraph* Graph : BP->UbergraphPages)
	{
		if (!Graph) continue;
		for (UEdGraphNode* Node : Graph->Nodes)
		{
			if (!Node) continue;
			for (UEdGraphPin* Pin : Node->Pins)
			{
				if (Pin && Pin->PinType.PinCategory == UEdGraphSchema_K2::PC_Exec && Pin->Direction == EGPD_Output && Pin->LinkedTo.Num() == 0)
				{
					TSharedPtr<FJsonObject> Item = MakeShared<FJsonObject>();
					Item->SetStringField(TEXT("node"), Node->GetNodeTitle(ENodeTitleType::ListView).ToString());
					Item->SetStringField(TEXT("pin"), Pin->GetName());
					UnconnectedList.Add(MakeShared<FJsonValueObject>(Item));
				}
			}
		}
	}

	Result->SetBoolField(TEXT("success"), true);
	Result->SetNumberField(TEXT("unconnected_count"), UnconnectedList.Num());
	Result->SetArrayField(TEXT("unconnected_pins"), UnconnectedList);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleFixBrokenReferences(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString BlueprintPath = Args->GetStringField(TEXT("blueprint_path"));

	UBlueprint* BP = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *BlueprintPath));
	if (!BP)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Blueprint not found."));
		return Result;
	}

	FBlueprintEditorUtils::RefreshAllNodes(BP);
	FKismetEditorUtilities::CompileBlueprint(BP);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("message"), TEXT("Refreshed nodes and attempted automatic reference reconnection."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleRefreshAllNodes(const TSharedPtr<FJsonObject>& Args)
{
	return HandleFixBrokenReferences(Args);
}

TSharedPtr<FJsonObject> FJagPilotBlueprintTools::HandleTriggerLiveCoding(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();

	ILiveCodingModule* LiveCoding = FModuleManager::GetModulePtr<ILiveCodingModule>(LIVE_CODING_MODULE_NAME);
	if (!LiveCoding)
	{
		LiveCoding = FModuleManager::LoadModulePtr<ILiveCodingModule>(LIVE_CODING_MODULE_NAME);
	}

	if (LiveCoding && LiveCoding->IsEnabledByDefault())
	{
		ELiveCodingCompileResult CompileResult = ELiveCodingCompileResult::Success;
		bool bStarted = LiveCoding->Compile(ELiveCodingCompileFlags::None, &CompileResult);
		Result->SetBoolField(TEXT("success"), bStarted);
		Result->SetStringField(TEXT("message"), bStarted ? TEXT("Live Coding compile initiated successfully.") : TEXT("Live Coding compile was not started."));
		return Result;
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Live Coding is not enabled in this editor session."));
	return Result;
}

