// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Tools/JagPilotActorTools.h"
#include "JagPilotToolRegistry.h"
#include "JagPilot.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"
#include "Engine/Blueprint.h"
#include "Engine/Selection.h"
#include "Engine/SkyLight.h"
#include "Components/SkyLightComponent.h"
#include "ScopedTransaction.h"

void FJagPilotActorTools::RegisterTools(UJagPilotToolRegistry* Registry)
{
	if (!Registry) return;

	// 1. spawn_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> ClassProp = MakeShared<FJsonObject>();
		ClassProp->SetStringField(TEXT("type"), TEXT("string"));
		ClassProp->SetStringField(TEXT("description"), TEXT("Actor class name or Blueprint path"));
		Props->SetObjectField(TEXT("actor_class"), ClassProp);
		TSharedPtr<FJsonObject> LocProp = MakeShared<FJsonObject>();
		LocProp->SetStringField(TEXT("type"), TEXT("array"));
		LocProp->SetStringField(TEXT("description"), TEXT("[X, Y, Z] world location"));
		Props->SetObjectField(TEXT("location"), LocProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleSpawnActor);
		Registry->RegisterTool(TEXT("spawn_actor"), TEXT("Spawns an Actor into the active level at a given location"), TEXT("Actor"), Schema, Handler);
	}

	// 2. transform_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> LocProp = MakeShared<FJsonObject>();
		LocProp->SetStringField(TEXT("type"), TEXT("array"));
		Props->SetObjectField(TEXT("location"), LocProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleTransformActor);
		Registry->RegisterTool(TEXT("transform_actor"), TEXT("Modifies location, rotation, or scale of an actor"), TEXT("Actor"), Schema, Handler);
	}

	// 3. attach_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> ChildProp = MakeShared<FJsonObject>();
		ChildProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("child_actor"), ChildProp);
		TSharedPtr<FJsonObject> ParentProp = MakeShared<FJsonObject>();
		ParentProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("parent_actor"), ParentProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleAttachActor);
		Registry->RegisterTool(TEXT("attach_actor"), TEXT("Parents a child actor to a parent actor in the world hierarchy"), TEXT("Actor"), Schema, Handler);
	}

	// 4. detach_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> ActorProp = MakeShared<FJsonObject>();
		ActorProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), ActorProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleDetachActor);
		Registry->RegisterTool(TEXT("detach_actor"), TEXT("Detaches an actor from its parent in the world hierarchy"), TEXT("Actor"), Schema, Handler);
	}

	// 5. snap_to_floor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> ActorProp = MakeShared<FJsonObject>();
		ActorProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), ActorProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleSnapToFloor);
		Registry->RegisterTool(TEXT("snap_to_floor"), TEXT("Performs a physics raycast downward to snap an actor onto the ground surface"), TEXT("Actor"), Schema, Handler);
	}

	// 6. set_actor_property
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> PropNameProp = MakeShared<FJsonObject>();
		PropNameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("property_name"), PropNameProp);
		TSharedPtr<FJsonObject> ValProp = MakeShared<FJsonObject>();
		ValProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("property_value"), ValProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleSetActorProperty);
		Registry->RegisterTool(TEXT("set_actor_property"), TEXT("Sets any reflected property value on an actor"), TEXT("Actor"), Schema, Handler);
	}

	// 7. select_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleSelectActor);
		Registry->RegisterTool(TEXT("select_actor"), TEXT("Selects an actor in the level editor viewport"), TEXT("Actor"), Schema, Handler);
	}

	// 8. delete_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleDeleteActor);
		Registry->RegisterTool(TEXT("delete_actor"), TEXT("Deletes an Actor from the active level (Undoable)"), TEXT("Actor"), Schema, Handler);
	}

	// 9. normalize_and_ground_mesh
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> SizeProp = MakeShared<FJsonObject>();
		SizeProp->SetStringField(TEXT("type"), TEXT("number"));
		SizeProp->SetStringField(TEXT("description"), TEXT("Target size in meters along largest dimension (Default: 1.0)"));
		Props->SetObjectField(TEXT("target_size_m"), SizeProp);
		TSharedPtr<FJsonObject> GroundProp = MakeShared<FJsonObject>();
		GroundProp->SetStringField(TEXT("type"), TEXT("number"));
		GroundProp->SetStringField(TEXT("description"), TEXT("Target ground Z in cm (Default: 0.0)"));
		Props->SetObjectField(TEXT("ground_z_cm"), GroundProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleNormalizeAndGround);
		Registry->RegisterTool(TEXT("normalize_and_ground_mesh"), TEXT("Normalizes AI-generated mesh dimensions to target meters and snaps bottom to ground level"), TEXT("Actor"), Schema, Handler);
	}

	// 10. setup_sky_light_hdri
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> IntensityProp = MakeShared<FJsonObject>();
		IntensityProp->SetStringField(TEXT("type"), TEXT("number"));
		IntensityProp->SetStringField(TEXT("description"), TEXT("SkyLight intensity (Default: 1.0)"));
		Props->SetObjectField(TEXT("intensity"), IntensityProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotActorTools::HandleSetupSkyLight);
		Registry->RegisterTool(TEXT("setup_sky_light_hdri"), TEXT("Configures or spawns real-time scene-capturing SkyLight for Lumen HDRI illumination"), TEXT("Rendering"), Schema, Handler);
	}
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleSpawnActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active editor world found."));
		return Result;
	}

	FString ClassName = Args->GetStringField(TEXT("actor_class"));
	UClass* ActorClass = nullptr;

	if (ClassName.StartsWith(TEXT("/")))
	{
		UBlueprint* Blueprint = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *ClassName));
		if (Blueprint)
		{
			ActorClass = Blueprint->GeneratedClass;
		}
	}

	if (!ActorClass)
	{
		ActorClass = UClass::TryFindTypeSlow<UClass>(ClassName);
	}

	if (!ActorClass)
	{
		ActorClass = AActor::StaticClass();
	}

	FVector Location = FVector::ZeroVector;
	const TArray<TSharedPtr<FJsonValue>>* LocArr = nullptr;
	if (Args->TryGetArrayField(TEXT("location"), LocArr) && LocArr && LocArr->Num() >= 3)
	{
		Location.X = (*LocArr)[0]->AsNumber();
		Location.Y = (*LocArr)[1]->AsNumber();
		Location.Z = (*LocArr)[2]->AsNumber();
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* NewActor = World->SpawnActor<AActor>(ActorClass, Location, FRotator::ZeroRotator, SpawnParams);
	if (!NewActor)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Failed to spawn actor."));
		return Result;
	}

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("actor_name"), NewActor->GetName());
	Result->SetStringField(TEXT("actor_label"), NewActor->GetActorLabel());
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleTransformActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active world."));
		return Result;
	}

	AActor* TargetActor = nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			TargetActor = *It;
			break;
		}
	}

	if (!TargetActor)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Actor '%s' not found."), *ActorName));
		return Result;
	}

	const TArray<TSharedPtr<FJsonValue>>* LocArr = nullptr;
	if (Args->TryGetArrayField(TEXT("location"), LocArr) && LocArr && LocArr->Num() >= 3)
	{
		FVector NewLoc((*LocArr)[0]->AsNumber(), (*LocArr)[1]->AsNumber(), (*LocArr)[2]->AsNumber());
		TargetActor->SetActorLocation(NewLoc);
	}

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Updated transform for %s"), *ActorName));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleAttachActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ChildName = Args->GetStringField(TEXT("child_actor"));
	FString ParentName = Args->GetStringField(TEXT("parent_actor"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	AActor* Child = nullptr;
	AActor* Parent = nullptr;

	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ChildName || It->GetActorLabel() == ChildName) Child = *It;
		if (It->GetName() == ParentName || It->GetActorLabel() == ParentName) Parent = *It;
	}

	if (!Child || !Parent)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Could not find child or parent actor."));
		return Result;
	}

	Child->AttachToActor(Parent, FAttachmentTransformRules::KeepWorldTransform);
	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Attached %s to %s"), *ChildName, *ParentName));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleDetachActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			It->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			Result->SetBoolField(TEXT("success"), true);
			Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Detached %s"), *ActorName));
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor not found."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleSnapToFloor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			FVector Start = It->GetActorLocation();
			FVector End = Start - FVector(0.f, 0.f, 10000.f);

			FHitResult HitResult;
			FCollisionQueryParams QueryParams;
			QueryParams.AddIgnoredActor(*It);

			if (World->LineTraceSingleByChannel(HitResult, Start, End, ECC_Visibility, QueryParams))
			{
				It->SetActorLocation(HitResult.ImpactPoint);
				Result->SetBoolField(TEXT("success"), true);
				Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Snapped %s to floor at Z=%.1f"), *ActorName, HitResult.ImpactPoint.Z));
				return Result;
			}
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Could not trace ground surface beneath actor."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleSetActorProperty(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));
	FString PropName = Args->GetStringField(TEXT("property_name"));
	FString PropVal = Args->GetStringField(TEXT("property_value"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			FProperty* Prop = It->GetClass()->FindPropertyByName(FName(*PropName));
			if (Prop)
			{
				Prop->ImportText_Direct(*PropVal, Prop->ContainerPtrToValuePtr<void>(*It), *It, PPF_None);
				Result->SetBoolField(TEXT("success"), true);
				Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Set %s.%s = %s"), *ActorName, *PropName, *PropVal));
				return Result;
			}
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Property or actor not found."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleSelectActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			if (GEditor)
			{
				GEditor->SelectNone(false, true);
				GEditor->SelectActor(*It, true, true);
			}
			Result->SetBoolField(TEXT("success"), true);
			Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Selected actor %s"), *ActorName));
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor not found."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleNormalizeAndGround(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));
	float TargetSizeM = Args->HasField(TEXT("target_size_m")) ? Args->GetNumberField(TEXT("target_size_m")) : 1.0f;
	float GroundZCm = Args->HasField(TEXT("ground_z_cm")) ? Args->GetNumberField(TEXT("ground_z_cm")) : 0.0f;

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active world."));
		return Result;
	}

	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			AActor* Actor = *It;
			FVector Origin, Extent;
			Actor->GetActorBounds(false, Origin, Extent);

			float ActualMaxCm = 2.0f * FMath::Max3(Extent.X, Extent.Y, Extent.Z);
			float TargetMaxCm = TargetSizeM * 100.0f;

			if (ActualMaxCm > 1.0f)
			{
				float ScaleMultiplier = TargetMaxCm / ActualMaxCm;
				FVector CurScale = Actor->GetActorScale3D();
				Actor->SetActorScale3D(CurScale * ScaleMultiplier);
			}

			// Re-measure after scaling and ground
			Actor->GetActorBounds(false, Origin, Extent);
			float BottomZ = Origin.Z - Extent.Z;
			float ShiftZ = GroundZCm - BottomZ;

			FVector CurLoc = Actor->GetActorLocation();
			Actor->SetActorLocation(CurLoc + FVector(0.f, 0.f, ShiftZ));

			Result->SetBoolField(TEXT("success"), true);
			Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Normalized %s to %.2fm and grounded to Z=%.1fcm"), *ActorName, TargetSizeM, GroundZCm));
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor not found."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleSetupSkyLight(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	float Intensity = Args->HasField(TEXT("intensity")) ? Args->GetNumberField(TEXT("intensity")) : 1.0f;

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active world."));
		return Result;
	}

	ASkyLight* SkyLight = nullptr;
	for (TActorIterator<ASkyLight> It(World); It; ++It)
	{
		SkyLight = *It;
		break;
	}

	if (!SkyLight)
	{
		FActorSpawnParameters Params;
		SkyLight = World->SpawnActor<ASkyLight>(ASkyLight::StaticClass(), FVector(0.f, 0.f, 300.f), FRotator::ZeroRotator, Params);
		if (SkyLight)
		{
			SkyLight->SetActorLabel(TEXT("JagPilot_SkyLight"));
		}
	}

	if (SkyLight && SkyLight->GetLightComponent())
	{
		SkyLight->GetLightComponent()->SetIntensity(Intensity);
		SkyLight->GetLightComponent()->bRealTimeCapture = true;
		SkyLight->GetLightComponent()->RecaptureSky();

		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Configured SkyLight for real-time HDRI scene capture at intensity %.2f"), Intensity));
		return Result;
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Failed to configure SkyLight."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotActorTools::HandleDeleteActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ActorName = Args->GetStringField(TEXT("actor_name"));

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Editor world context not available."));
		return Result;
	}

	AActor* TargetActor = nullptr;
	for (TActorIterator<AActor> It(World); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			TargetActor = *It;
			break;
		}
	}

	if (!TargetActor)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Actor '%s' not found."), *ActorName));
		return Result;
	}

	World->EditorDestroyActor(TargetActor, true);
	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Destroyed actor '%s'."), *ActorName));
	return Result;
}


