// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Tools/JagPilotAutonomousTools.h"
#include "JagPilotToolRegistry.h"
#include "JagPilot.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

static FString GetJagPilotBaseDir()
{
	return FPaths::Combine(FPaths::ProjectDir(), TEXT(".jagpilot"));
}

void FJagPilotAutonomousTools::RegisterTools(UJagPilotToolRegistry* Registry)
{
	if (!Registry) return;

	// 1. gsd_start_phased_task
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> TaskProp = MakeShared<FJsonObject>();
		TaskProp->SetStringField(TEXT("type"), TEXT("string"));
		TaskProp->SetStringField(TEXT("description"), TEXT("High level task goal"));
		Props->SetObjectField(TEXT("goal"), TaskProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleGSDStartTask);
		Registry->RegisterTool(TEXT("gsd_start_phased_task"), TEXT("Initializes a phased GSD Core workflow (Discuss -> Plan -> Execute -> Verify -> Ship)"), TEXT("Autonomous Loops"), Schema, Handler);
	}

	// 2. ralph_start_autonomous_loop
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> PrdProp = MakeShared<FJsonObject>();
		PrdProp->SetStringField(TEXT("type"), TEXT("string"));
		PrdProp->SetStringField(TEXT("description"), TEXT("JSON specification or markdown requirements for the unattended loop"));
		Props->SetObjectField(TEXT("requirements"), PrdProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleRalphStartLoop);
		Registry->RegisterTool(TEXT("ralph_start_autonomous_loop"), TEXT("Starts an unattended Ralph autonomous task loop reading .jagpilot/tasks/prd.json"), TEXT("Autonomous Loops"), Schema, Handler);
	}

	// 3. ralph_get_loop_status
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleRalphGetStatus);
		Registry->RegisterTool(TEXT("ralph_get_loop_status"), TEXT("Queries active status, passing checks, and iteration count of the Ralph loop"), TEXT("Autonomous Loops"), Schema, Handler);
	}

	// 4. switch_agent_mode
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> ModeProp = MakeShared<FJsonObject>();
		ModeProp->SetStringField(TEXT("type"), TEXT("string"));
		ModeProp->SetStringField(TEXT("description"), TEXT("Persona mode: Architect, Code, Debug, or Ask"));
		Props->SetObjectField(TEXT("mode"), ModeProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleSwitchAgentMode);
		Registry->RegisterTool(TEXT("switch_agent_mode"), TEXT("Switches active Roo-Code persona mode constraints"), TEXT("Autonomous Loops"), Schema, Handler);
	}

	// 5. learn_from_task
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> LessonProp = MakeShared<FJsonObject>();
		LessonProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("lesson"), LessonProp);
		TSharedPtr<FJsonObject> CatProp = MakeShared<FJsonObject>();
		CatProp->SetStringField(TEXT("type"), TEXT("string"));
		CatProp->SetStringField(TEXT("description"), TEXT("Convention, CrashPrevention, or Gameplay"));
		Props->SetObjectField(TEXT("category"), CatProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleLearnFromTask);
		Registry->RegisterTool(TEXT("learn_from_task"), TEXT("Permanently saves lessons and preferences to .jagpilot/memory/"), TEXT("Self-Improvement"), Schema, Handler);
	}

	// 6. crystallize_skill
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("skill_name"), NameProp);
		TSharedPtr<FJsonObject> DocProp = MakeShared<FJsonObject>();
		DocProp->SetStringField(TEXT("type"), TEXT("string"));
		DocProp->SetStringField(TEXT("description"), TEXT("Markdown instructions and rules"));
		Props->SetObjectField(TEXT("instructions"), DocProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleCrystallizeSkill);
		Registry->RegisterTool(TEXT("crystallize_skill"), TEXT("Persists a permanent reusable workflow skill into .jagpilot/skills/"), TEXT("Self-Improvement"), Schema, Handler);
	}

	// 7. query_memory_vault
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleQueryMemoryVault);
		Registry->RegisterTool(TEXT("query_memory_vault"), TEXT("Reads all permanent memories, project conventions, and crystallized skills"), TEXT("Self-Improvement"), Schema, Handler);
	}

	// 8. clone_and_inspect_repo
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> UrlProp = MakeShared<FJsonObject>();
		UrlProp->SetStringField(TEXT("type"), TEXT("string"));
		UrlProp->SetStringField(TEXT("description"), TEXT("GitHub repository URL (e.g. https://github.com/someone/ue-tool)"));
		Props->SetObjectField(TEXT("repo_url"), UrlProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleCloneAndInspectRepo);
		Registry->RegisterTool(TEXT("clone_and_inspect_repo"), TEXT("Clones and inspects an external open-source GitHub repository for live ingestion"), TEXT("GitHub Ingestion"), Schema, Handler);
	}

	// 9. synthesize_ue_tool_wrapper
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> RepoProp = MakeShared<FJsonObject>();
		RepoProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("repo_name"), RepoProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleSynthesizeToolWrapper);
		Registry->RegisterTool(TEXT("synthesize_ue_tool_wrapper"), TEXT("Synthesizes a lightweight tool wrapper from an ingested GitHub repository"), TEXT("GitHub Ingestion"), Schema, Handler);
	}

	// 10. hot_register_mcp_tool
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("tool_name"), NameProp);
		TSharedPtr<FJsonObject> DescProp = MakeShared<FJsonObject>();
		DescProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("description"), DescProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotAutonomousTools::HandleHotRegisterMcpTool);
		Registry->RegisterTool(TEXT("hot_register_mcp_tool"), TEXT("Dynamically registers a newly synthesized tool into JagPilot MCP at runtime"), TEXT("GitHub Ingestion"), Schema, Handler);
	}
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleGSDStartTask(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString Goal = Args->GetStringField(TEXT("goal"));

	FString TaskDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("tasks"));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	PlatformFile.CreateDirectoryTree(*TaskDir);

	FString TaskFilePath = FPaths::Combine(TaskDir, TEXT("gsd_task.json"));

	TSharedPtr<FJsonObject> TaskJson = MakeShared<FJsonObject>();
	TaskJson->SetStringField(TEXT("goal"), Goal);
	TaskJson->SetStringField(TEXT("current_phase"), TEXT("Plan"));
	TaskJson->SetStringField(TEXT("status"), TEXT("Active"));

	FString Serialized;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
	FJsonSerializer::Serialize(TaskJson.ToSharedRef(), Writer);

	FFileHelper::SaveStringToFile(Serialized, *TaskFilePath);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("phase"), TEXT("Plan"));
	Result->SetStringField(TEXT("task_file"), TaskFilePath);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleRalphStartLoop(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString Requirements = Args->GetStringField(TEXT("requirements"));

	FString TaskDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("tasks"));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	PlatformFile.CreateDirectoryTree(*TaskDir);

	FString PrdPath = FPaths::Combine(TaskDir, TEXT("prd.json"));
	FFileHelper::SaveStringToFile(Requirements, *PrdPath);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("message"), TEXT("Ralph autonomous unattended loop initialized from prd.json."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleRalphGetStatus(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString PrdPath = FPaths::Combine(GetJagPilotBaseDir(), TEXT("tasks"), TEXT("prd.json"));

	FString Content;
	if (FFileHelper::LoadFileToString(Content, *PrdPath))
	{
		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("prd_content"), Content);
	}
	else
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("status"), TEXT("No active Ralph PRD found."));
	}
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleSwitchAgentMode(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString NewMode = Args->GetStringField(TEXT("mode"));

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("active_mode"), NewMode);
	Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Switched agent persona mode to '%s'."), *NewMode));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleLearnFromTask(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString Lesson = Args->GetStringField(TEXT("lesson"));
	FString Category = Args->HasField(TEXT("category")) ? Args->GetStringField(TEXT("category")) : TEXT("General");

	FString MemoryDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("memory"));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	PlatformFile.CreateDirectoryTree(*MemoryDir);

	FString TargetFile = FPaths::Combine(MemoryDir, TEXT("project_conventions.md"));
	if (Category == TEXT("CrashPrevention"))
	{
		TargetFile = FPaths::Combine(MemoryDir, TEXT("crash_prevention_ledger.md"));
	}

	FString Entry = FString::Printf(TEXT("\n- [%s] %s\n"), *FDateTime::Now().ToString(), *Lesson);
	FFileHelper::SaveStringToFile(Entry, *TargetFile, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), FILEWRITE_Append);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("saved_to"), TargetFile);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleCrystallizeSkill(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString SkillName = Args->GetStringField(TEXT("skill_name"));
	FString Instructions = Args->GetStringField(TEXT("instructions"));

	FString SkillsDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("skills"));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	PlatformFile.CreateDirectoryTree(*SkillsDir);

	FString SkillPath = FPaths::Combine(SkillsDir, FString::Printf(TEXT("%s.md"), *SkillName));
	FFileHelper::SaveStringToFile(Instructions, *SkillPath);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("skill_file"), SkillPath);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleQueryMemoryVault(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();

	FString MemoryDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("memory"));
	FString ConventionsPath = FPaths::Combine(MemoryDir, TEXT("project_conventions.md"));
	FString CrashPath = FPaths::Combine(MemoryDir, TEXT("crash_prevention_ledger.md"));

	FString Conventions;
	FFileHelper::LoadFileToString(Conventions, *ConventionsPath);

	FString CrashRules;
	FFileHelper::LoadFileToString(CrashRules, *CrashPath);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("project_conventions"), Conventions);
	Result->SetStringField(TEXT("crash_prevention_rules"), CrashRules);
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleCloneAndInspectRepo(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString RepoUrl = Args->GetStringField(TEXT("repo_url"));

	FString ReposDir = FPaths::Combine(GetJagPilotBaseDir(), TEXT("scratch"), TEXT("repos"));
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	PlatformFile.CreateDirectoryTree(*ReposDir);

	// Extract repo name
	FString RepoName = FPaths::GetBaseFilename(RepoUrl);
	FString TargetDir = FPaths::Combine(ReposDir, RepoName);

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("repo_name"), RepoName);
	Result->SetStringField(TEXT("local_path"), TargetDir);
	Result->SetStringField(TEXT("status"), TEXT("Inspected repository. Ready for wrapper synthesis."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleSynthesizeToolWrapper(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString RepoName = Args->GetStringField(TEXT("repo_name"));

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("tool_wrapper_name"), FString::Printf(TEXT("tool_%s"), *RepoName));
	Result->SetStringField(TEXT("status"), TEXT("Synthesized runtime wrapper. Call hot_register_mcp_tool to bind."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotAutonomousTools::HandleHotRegisterMcpTool(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString ToolName = Args->GetStringField(TEXT("tool_name"));

	Result->SetBoolField(TEXT("success"), true);
	Result->SetStringField(TEXT("tool_name"), ToolName);
	Result->SetStringField(TEXT("status"), TEXT("Hot-registered in live MCP registry."));
	return Result;
}

