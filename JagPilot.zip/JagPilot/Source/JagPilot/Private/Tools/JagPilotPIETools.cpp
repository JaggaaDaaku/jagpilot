// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Tools/JagPilotPIETools.h"
#include "JagPilotToolRegistry.h"
#include "JagPilot.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"

void FJagPilotPIETools::RegisterTools(UJagPilotToolRegistry* Registry)
{
	if (!Registry) return;

	// 1. play_in_editor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandlePlayInEditor);
		Registry->RegisterTool(TEXT("play_in_editor"), TEXT("Starts Play-In-Editor (PIE) runtime game simulation"), TEXT("PIE Runtime"), Schema, Handler);
	}

	// 2. stop_pie
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandleStopPIE);
		Registry->RegisterTool(TEXT("stop_pie"), TEXT("Stops the active Play-In-Editor (PIE) simulation"), TEXT("PIE Runtime"), Schema, Handler);
	}

	// 3. pie_teleport_actor
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> LocProp = MakeShared<FJsonObject>();
		LocProp->SetStringField(TEXT("type"), TEXT("array"));
		Props->SetObjectField(TEXT("location"), LocProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandlePIETeleportActor);
		Registry->RegisterTool(TEXT("pie_teleport_actor"), TEXT("Teleports an actor in the live running PIE game world"), TEXT("PIE Runtime"), Schema, Handler);
	}

	// 4. pie_console_command
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> CmdProp = MakeShared<FJsonObject>();
		CmdProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("command"), CmdProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandlePIEConsoleCommand);
		Registry->RegisterTool(TEXT("pie_console_command"), TEXT("Executes an engine console command in the live PIE world"), TEXT("PIE Runtime"), Schema, Handler);
	}

	// 5. pie_set_property
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> PropName = MakeShared<FJsonObject>();
		PropName->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("property_name"), PropName);
		TSharedPtr<FJsonObject> ValProp = MakeShared<FJsonObject>();
		ValProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("property_value"), ValProp);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandlePIESetProperty);
		Registry->RegisterTool(TEXT("pie_set_property"), TEXT("Modifies an actor property during live PIE execution"), TEXT("PIE Runtime"), Schema, Handler);
	}

	// 6. pie_get_property
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));
		TSharedPtr<FJsonObject> Props = MakeShared<FJsonObject>();
		TSharedPtr<FJsonObject> NameProp = MakeShared<FJsonObject>();
		NameProp->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("actor_name"), NameProp);
		TSharedPtr<FJsonObject> PropName = MakeShared<FJsonObject>();
		PropName->SetStringField(TEXT("type"), TEXT("string"));
		Props->SetObjectField(TEXT("property_name"), PropName);
		Schema->SetObjectField(TEXT("properties"), Props);

		FJagPilotToolHandler Handler;
		Handler.BindStatic(&FJagPilotPIETools::HandlePIEGetProperty);
		Registry->RegisterTool(TEXT("pie_get_property"), TEXT("Inspects an actor property value from the live PIE execution"), TEXT("PIE Runtime"), Schema, Handler);
	}
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandlePlayInEditor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (GEditor && !GEditor->PlayWorld)
	{
		FRequestPlaySessionParams Params;
		GEditor->RequestPlaySession(Params);
		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("message"), TEXT("Requested Play-In-Editor session."));
	}
	else
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("PIE session is already active."));
	}
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandleStopPIE(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (GEditor && GEditor->PlayWorld)
	{
		GEditor->RequestEndPlayMap();
		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("message"), TEXT("Stopped Play-In-Editor session."));
	}
	else
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active PIE session found."));
	}
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandlePIETeleportActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!GEditor || !GEditor->PlayWorld)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active PIE world."));
		return Result;
	}

	FString ActorName = Args->GetStringField(TEXT("actor_name"));
	const TArray<TSharedPtr<FJsonValue>>* LocArr = nullptr;

	if (Args->TryGetArrayField(TEXT("location"), LocArr) && LocArr && LocArr->Num() >= 3)
	{
		FVector NewLoc((*LocArr)[0]->AsNumber(), (*LocArr)[1]->AsNumber(), (*LocArr)[2]->AsNumber());

		for (TActorIterator<AActor> It(GEditor->PlayWorld.Get()); It; ++It)
		{
			if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
			{
				It->TeleportTo(NewLoc, It->GetActorRotation());
				Result->SetBoolField(TEXT("success"), true);
				Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Teleported %s to [%.1f, %.1f, %.1f] in PIE"), *ActorName, NewLoc.X, NewLoc.Y, NewLoc.Z));
				return Result;
			}
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor not found in PIE world."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandlePIEConsoleCommand(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	FString Command = Args->GetStringField(TEXT("command"));

	UWorld* World = GEditor ? (GEditor->PlayWorld ? GEditor->PlayWorld.Get() : GEditor->GetEditorWorldContext().World()) : nullptr;
	if (GEngine && World)
	{
		GEngine->Exec(World, *Command);
		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Executed console command: %s"), *Command));
	}
	else
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Failed to execute console command."));
	}
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandlePIESetProperty(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!GEditor || !GEditor->PlayWorld)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active PIE world."));
		return Result;
	}

	FString ActorName = Args->GetStringField(TEXT("actor_name"));
	FString PropName = Args->GetStringField(TEXT("property_name"));
	FString PropVal = Args->GetStringField(TEXT("property_value"));

	for (TActorIterator<AActor> It(GEditor->PlayWorld.Get()); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			FProperty* Prop = It->GetClass()->FindPropertyByName(FName(*PropName));
			if (Prop)
			{
				Prop->ImportText_Direct(*PropVal, Prop->ContainerPtrToValuePtr<void>(*It), *It, PPF_None);
				Result->SetBoolField(TEXT("success"), true);
				Result->SetStringField(TEXT("message"), FString::Printf(TEXT("Updated PIE property %s.%s = %s"), *ActorName, *PropName, *PropVal));
				return Result;
			}
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor or property not found in PIE."));
	return Result;
}

TSharedPtr<FJsonObject> FJagPilotPIETools::HandlePIEGetProperty(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!GEditor || !GEditor->PlayWorld)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active PIE world."));
		return Result;
	}

	FString ActorName = Args->GetStringField(TEXT("actor_name"));
	FString PropName = Args->GetStringField(TEXT("property_name"));

	for (TActorIterator<AActor> It(GEditor->PlayWorld.Get()); It; ++It)
	{
		if (It->GetName() == ActorName || It->GetActorLabel() == ActorName)
		{
			FProperty* Prop = It->GetClass()->FindPropertyByName(FName(*PropName));
			if (Prop)
			{
				FString ValStr;
				Prop->ExportTextItem_Direct(ValStr, Prop->ContainerPtrToValuePtr<void>(*It), nullptr, *It, PPF_None);
				Result->SetBoolField(TEXT("success"), true);
				Result->SetStringField(TEXT("property_value"), ValStr);
				return Result;
			}
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), TEXT("Actor or property not found in PIE."));
	return Result;
}

