// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilotToolRegistry.h"
#include "JagPilot.h"
#include "JagPilotSubsystem.h"
#include "Tools/JagPilotAssetTools.h"
#include "Tools/JagPilotActorTools.h"
#include "Tools/JagPilotBlueprintTools.h"
#include "Tools/JagPilotPIETools.h"
#include "Tools/JagPilotAutonomousTools.h"
#include "Editor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"
#include "Engine/Selection.h"
#include "ScopedTransaction.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Serialization/JsonSerializer.h"

UJagPilotToolRegistry::UJagPilotToolRegistry()
{
}

void UJagPilotToolRegistry::InitializeDefaultTools()
{
	// 1. Asset Tools
	FJagPilotAssetTools::RegisterTools(this);

	// 2. Actor & World Tools
	FJagPilotActorTools::RegisterTools(this);

	// 3. Blueprint & Self-Healing Tools
	FJagPilotBlueprintTools::RegisterTools(this);

	// 4. Live PIE Runtime Tools
	FJagPilotPIETools::RegisterTools(this);

	// 5. Autonomous Loops, GSD, Ralph, Memory, GitHub Tools
	FJagPilotAutonomousTools::RegisterTools(this);

	// 6. vram_throttle_status
	{
		TSharedPtr<FJsonObject> Schema = MakeShared<FJsonObject>();
		Schema->SetStringField(TEXT("type"), TEXT("object"));

		FJagPilotToolHandler Handler;
		Handler.BindUObject(this, &UJagPilotToolRegistry::HandleVRAMStatus);
		RegisterTool(TEXT("vram_throttle_status"), TEXT("Queries RTX 3070 8GB VRAM Arbitrator status"), TEXT("Hardware"), Schema, Handler);
	}

	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotToolRegistry: Initialized %d core MCP tools across all modular suites."), RegisteredTools.Num());
}

void UJagPilotToolRegistry::RegisterTool(const FString& Name, const FString& Description, const FString& Category, const TSharedPtr<FJsonObject>& InputSchema, const FJagPilotToolHandler& Handler)
{
	FJagPilotToolInfo Info;
	Info.Name = Name;
	Info.Description = Description;
	Info.Category = Category;
	Info.InputSchema = InputSchema;
	Info.Handler = Handler;

	RegisteredTools.Add(Name, Info);
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::ExecuteTool(const FString& Name, const TSharedPtr<FJsonObject>& Args)
{
	FJagPilotToolInfo* ToolInfo = RegisteredTools.Find(Name);
	if (!ToolInfo)
	{
		TSharedPtr<FJsonObject> ErrorObj = MakeShared<FJsonObject>();
		ErrorObj->SetBoolField(TEXT("success"), false);
		ErrorObj->SetStringField(TEXT("error"), FString::Printf(TEXT("Tool '%s' not found in JagPilot registry."), *Name));
		return ErrorObj;
	}

	// Wrap execution in FScopedTransaction for non-destructive undo/redo
	FScopedTransaction Transaction(FText::FromString(FString::Printf(TEXT("JagPilot Tool: %s"), *Name)));

	return ToolInfo->Handler.Execute(Args);
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::GenerateMCPToolsList() const
{
	TSharedPtr<FJsonObject> Root = MakeShared<FJsonObject>();
	TArray<TSharedPtr<FJsonValue>> ToolsArray;

	for (const auto& Pair : RegisteredTools)
	{
		const FJagPilotToolInfo& Tool = Pair.Value;
		TSharedPtr<FJsonObject> ToolObj = MakeShared<FJsonObject>();
		ToolObj->SetStringField(TEXT("name"), Tool.Name);
		ToolObj->SetStringField(TEXT("description"), Tool.Description);
		if (Tool.InputSchema.IsValid())
		{
			ToolObj->SetObjectField(TEXT("inputSchema"), Tool.InputSchema);
		}
		ToolsArray.Add(MakeShared<FJsonValueObject>(ToolObj));
	}

	Root->SetArrayField(TEXT("tools"), ToolsArray);
	return Root;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleFindAssets(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	TArray<TSharedPtr<FJsonValue>> AssetsArray;

	FString PackagePath = TEXT("/Game");
	if (Args.IsValid() && Args->HasField(TEXT("package_path")))
	{
		PackagePath = Args->GetStringField(TEXT("package_path"));
	}

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	TArray<FAssetData> AssetDataList;
	AssetRegistryModule.Get().GetAssetsByPath(FName(*PackagePath), AssetDataList, true);

	for (const FAssetData& AssetData : AssetDataList)
	{
		TSharedPtr<FJsonObject> AssetObj = MakeShared<FJsonObject>();
		AssetObj->SetStringField(TEXT("name"), AssetData.AssetName.ToString());
		AssetObj->SetStringField(TEXT("class"), AssetData.AssetClassPath.GetAssetName().ToString());
		AssetObj->SetStringField(TEXT("path"), AssetData.GetObjectPathString());
		AssetsArray.Add(MakeShared<FJsonValueObject>(AssetObj));
	}

	Result->SetBoolField(TEXT("success"), true);
	Result->SetNumberField(TEXT("count"), AssetsArray.Num());
	Result->SetArrayField(TEXT("assets"), AssetsArray);
	return Result;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleSpawnActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!GEditor)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("GEditor not available."));
		return Result;
	}

	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("No active Editor World found."));
		return Result;
	}

	FVector Location = FVector::ZeroVector;
	if (Args.IsValid() && Args->HasField(TEXT("location")))
	{
		const TArray<TSharedPtr<FJsonValue>>& LocArray = Args->GetArrayField(TEXT("location"));
		if (LocArray.Num() >= 3)
		{
			Location = FVector(LocArray[0]->AsNumber(), LocArray[1]->AsNumber(), LocArray[2]->AsNumber());
		}
	}

	FActorSpawnParameters SpawnParams;
	AActor* NewActor = World->SpawnActor<AActor>(AActor::StaticClass(), Location, FRotator::ZeroRotator, SpawnParams);
	if (NewActor)
	{
		Result->SetBoolField(TEXT("success"), true);
		Result->SetStringField(TEXT("actor_name"), NewActor->GetActorLabel());
		Result->SetStringField(TEXT("class"), NewActor->GetClass()->GetName());
	}
	else
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Failed to spawn actor."));
	}

	return Result;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleGetSelectedActors(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	TArray<TSharedPtr<FJsonValue>> SelectedArray;

	if (GEditor)
	{
		USelection* SelectedActors = GEditor->GetSelectedActors();
		if (SelectedActors)
		{
			for (FSelectionIterator It(*SelectedActors); It; ++It)
			{
				if (AActor* Actor = Cast<AActor>(*It))
				{
					TSharedPtr<FJsonObject> ActorObj = MakeShared<FJsonObject>();
					ActorObj->SetStringField(TEXT("label"), Actor->GetActorLabel());
					ActorObj->SetStringField(TEXT("class"), Actor->GetClass()->GetName());
					SelectedArray.Add(MakeShared<FJsonValueObject>(ActorObj));
				}
			}
		}
	}

	Result->SetBoolField(TEXT("success"), true);
	Result->SetNumberField(TEXT("count"), SelectedArray.Num());
	Result->SetArrayField(TEXT("selected_actors"), SelectedArray);
	return Result;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleSetActorTransform(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!Args.IsValid() || !Args->HasField(TEXT("actor_name")))
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Missing 'actor_name' parameter."));
		return Result;
	}

	FString TargetName = Args->GetStringField(TEXT("actor_name"));
	if (!GEditor)
	{
		Result->SetBoolField(TEXT("success"), false);
		return Result;
	}

	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		return Result;
	}

	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* Actor = *It;
		if (Actor && Actor->GetActorLabel().Equals(TargetName, ESearchCase::IgnoreCase))
		{
			if (Args->HasField(TEXT("location")))
			{
				const TArray<TSharedPtr<FJsonValue>>& LocArray = Args->GetArrayField(TEXT("location"));
				if (LocArray.Num() >= 3)
				{
					Actor->SetActorLocation(FVector(LocArray[0]->AsNumber(), LocArray[1]->AsNumber(), LocArray[2]->AsNumber()));
				}
			}
			Result->SetBoolField(TEXT("success"), true);
			Result->SetStringField(TEXT("updated_actor"), Actor->GetActorLabel());
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Actor '%s' not found."), *TargetName));
	return Result;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleDeleteActor(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (!Args.IsValid() || !Args->HasField(TEXT("actor_name")))
	{
		Result->SetBoolField(TEXT("success"), false);
		Result->SetStringField(TEXT("error"), TEXT("Missing 'actor_name' parameter."));
		return Result;
	}

	FString TargetName = Args->GetStringField(TEXT("actor_name"));
	if (!GEditor)
	{
		Result->SetBoolField(TEXT("success"), false);
		return Result;
	}

	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World)
	{
		Result->SetBoolField(TEXT("success"), false);
		return Result;
	}

	for (TActorIterator<AActor> It(World); It; ++It)
	{
		AActor* Actor = *It;
		if (Actor && Actor->GetActorLabel().Equals(TargetName, ESearchCase::IgnoreCase))
		{
			FString DeletedLabel = Actor->GetActorLabel();
			Actor->Destroy();
			Result->SetBoolField(TEXT("success"), true);
			Result->SetStringField(TEXT("deleted_actor"), DeletedLabel);
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	Result->SetStringField(TEXT("error"), FString::Printf(TEXT("Actor '%s' not found for deletion."), *TargetName));
	return Result;
}

TSharedPtr<FJsonObject> UJagPilotToolRegistry::HandleVRAMStatus(const TSharedPtr<FJsonObject>& Args)
{
	TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
	if (GEditor)
	{
		if (UJagPilotSubsystem* Subsystem = GEditor->GetEditorSubsystem<UJagPilotSubsystem>())
		{
			Result->SetBoolField(TEXT("success"), true);
			Result->SetBoolField(TEXT("vram_throttled_for_ai"), Subsystem->IsGenerativeTaskRunning());
			Result->SetStringField(TEXT("hardware_profile"), TEXT("RTX 3070 Laptop (8GB VRAM) + Intel i7-12700H + 24GB DDR4"));
			return Result;
		}
	}

	Result->SetBoolField(TEXT("success"), false);
	return Result;
}
