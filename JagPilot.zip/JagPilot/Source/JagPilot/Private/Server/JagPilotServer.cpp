// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Server/JagPilotServer.h"
#include "JagPilot.h"
#include "JagPilotToolRegistry.h"
#include "JagPilotSubsystem.h"
#include "Editor.h"
#include "Async/Async.h"
#include "IPAddress.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

FJagPilotServer::FJagPilotServer(int32 InPort, UJagPilotToolRegistry* InRegistry)
	: Port(InPort)
	, bIsRunning(false)
	, Thread(nullptr)
	, ListenSocket(nullptr)
	, ToolRegistry(InRegistry)
{
}

FJagPilotServer::~FJagPilotServer()
{
	StopServer();
}

bool FJagPilotServer::Start()
{
	if (bIsRunning)
	{
		return true;
	}

	ISocketSubsystem* SocketSub = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
	if (!SocketSub)
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotServer: Failed to get SocketSubsystem."));
		return false;
	}

	TSharedRef<FInternetAddr> Addr = SocketSub->CreateInternetAddr();
	bool bIsValidIp = false;
	Addr->SetIp(TEXT("127.0.0.1"), bIsValidIp);
	Addr->SetPort(Port);

	ListenSocket = SocketSub->CreateSocket(NAME_Stream, TEXT("JagPilotServerListenSocket"), false);
	if (!ListenSocket)
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotServer: Failed to create ListenSocket."));
		return false;
	}

	ListenSocket->SetReuseAddr(true);
	ListenSocket->SetNonBlocking(true);

	if (!ListenSocket->Bind(*Addr))
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotServer: Failed to bind to 127.0.0.1:%d"), Port);
		SocketSub->DestroySocket(ListenSocket);
		ListenSocket = nullptr;
		return false;
	}

	if (!ListenSocket->Listen(16))
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotServer: Failed to listen on socket."));
		SocketSub->DestroySocket(ListenSocket);
		ListenSocket = nullptr;
		return false;
	}

	bIsRunning = true;
	Thread = FRunnableThread::Create(this, TEXT("JagPilotServerThread"), 128 * 1024, TPri_Normal);

	UE_LOG(LogJagPilot, Log, TEXT("JagPilotServer: MCP JSON-RPC Server listening on http://127.0.0.1:%d"), Port);
	return true;
}

void FJagPilotServer::StopServer()
{
	if (!bIsRunning)
	{
		return;
	}

	bIsRunning = false;

	if (ListenSocket)
	{
		ListenSocket->Close();
		ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ListenSocket);
		ListenSocket = nullptr;
	}

	if (Thread)
	{
		Thread->WaitForCompletion();
		delete Thread;
		Thread = nullptr;
	}

	UE_LOG(LogJagPilot, Log, TEXT("JagPilotServer: Stopped safely."));
}

bool FJagPilotServer::Init()
{
	return true;
}

uint32 FJagPilotServer::Run()
{
	while (bIsRunning)
	{
		if (!ListenSocket)
		{
			break;
		}

		bool bHasPendingConnection = false;
		ListenSocket->HasPendingConnection(bHasPendingConnection);

		if (bHasPendingConnection)
		{
			TSharedRef<FInternetAddr> ClientAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
			FSocket* ClientSocket = ListenSocket->Accept(*ClientAddr, TEXT("JagPilotClientSocket"));

			if (ClientSocket)
			{
				HandleClient(ClientSocket);
				ClientSocket->Close();
				ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(ClientSocket);
			}
		}

		FPlatformProcess::Sleep(0.005f); // 5ms sleep to prevent CPU spinning
	}

	return 0;
}

void FJagPilotServer::Stop()
{
	bIsRunning = false;
}

void FJagPilotServer::Exit()
{
}

void FJagPilotServer::HandleClient(FSocket* ClientSocket)
{
	TArray<uint8> ReceivedData;
	uint32 PendingDataSize = 0;

	// Wait up to 50ms for initial data
	int32 RetryCount = 0;
	while (bIsRunning && !ClientSocket->HasPendingData(PendingDataSize) && RetryCount < 10)
	{
		FPlatformProcess::Sleep(0.005f);
		RetryCount++;
	}

	if (!ClientSocket->HasPendingData(PendingDataSize) || PendingDataSize == 0)
	{
		return;
	}

	ReceivedData.SetNumUninitialized(PendingDataSize + 1);
	int32 BytesRead = 0;
	if (ClientSocket->Recv(ReceivedData.GetData(), PendingDataSize, BytesRead))
	{
		ReceivedData[BytesRead] = 0;
		FString RequestStr = UTF8_TO_TCHAR(reinterpret_cast<const char*>(ReceivedData.GetData()));

		FString ResponseStr = ProcessHttpRequest(RequestStr);
		FTCHARToUTF8 Utf8Response(*ResponseStr);

		int32 BytesSent = 0;
		ClientSocket->Send(reinterpret_cast<const uint8*>(Utf8Response.Get()), Utf8Response.Length(), BytesSent);
	}
}

FString FJagPilotServer::ProcessHttpRequest(const FString& RawRequest)
{
	// Parse HTTP Method and Path
	FString FirstLine;
	RawRequest.Split(TEXT("\r\n"), &FirstLine, nullptr);

	TArray<FString> Tokens;
	FirstLine.ParseIntoArray(Tokens, TEXT(" "), true);

	FString Method = Tokens.Num() > 0 ? Tokens[0] : TEXT("GET");
	FString Path = Tokens.Num() > 1 ? Tokens[1] : TEXT("/");

	// Handle CORS Pre-flight OPTIONS request
	if (Method == TEXT("OPTIONS"))
	{
		return TEXT("HTTP/1.1 204 No Content\r\n")
			TEXT("Access-Control-Allow-Origin: *\r\n")
			TEXT("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
			TEXT("Access-Control-Allow-Headers: Content-Type, Authorization, x-api-key\r\n")
			TEXT("Connection: close\r\n\r\n");
	}

	// Status / Health Check endpoint
	if (Method == TEXT("GET") && (Path == TEXT("/") || Path == TEXT("/health") || Path == TEXT("/status")))
	{
		TSharedPtr<FJsonObject> StatusObj = MakeShared<FJsonObject>();
		StatusObj->SetStringField(TEXT("status"), TEXT("ok"));
		StatusObj->SetStringField(TEXT("server"), TEXT("JagPilot"));
		StatusObj->SetStringField(TEXT("version"), TEXT("1.0.0"));
		StatusObj->SetNumberField(TEXT("port"), Port);

		if (GEditor)
		{
			UWorld* EditorWorld = GEditor->GetEditorWorldContext().World();
			StatusObj->SetStringField(TEXT("level"), EditorWorld ? EditorWorld->GetMapName() : TEXT("None"));
		}

		if (UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr)
		{
			StatusObj->SetBoolField(TEXT("vram_throttled"), Subsystem->IsGenerativeTaskRunning());
		}

		FString JsonBody;
		TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonBody);
		FJsonSerializer::Serialize(StatusObj.ToSharedRef(), Writer);

		return FString::Printf(
			TEXT("HTTP/1.1 200 OK\r\n")
			TEXT("Content-Type: application/json; charset=utf-8\r\n")
			TEXT("Access-Control-Allow-Origin: *\r\n")
			TEXT("Content-Length: %d\r\n")
			TEXT("Connection: close\r\n\r\n%s"),
			JsonBody.Len(),
			*JsonBody
		);
	}

	// JSON-RPC / MCP endpoints
	if (Method == TEXT("POST"))
	{
		// Extract request body after header separation \r\n\r\n
		FString Body;
		if (RawRequest.Split(TEXT("\r\n\r\n"), nullptr, &Body))
		{
			TSharedPtr<FJsonObject> RequestJson;
			TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Body);

			if (FJsonSerializer::Deserialize(Reader, RequestJson) && RequestJson.IsValid())
			{
				TSharedPtr<FJsonObject> ResponseJson = ProcessJsonRpc(RequestJson);

				FString ResponseBody;
				TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&ResponseBody);
				FJsonSerializer::Serialize(ResponseJson.ToSharedRef(), Writer);

				return FString::Printf(
					TEXT("HTTP/1.1 200 OK\r\n")
					TEXT("Content-Type: application/json; charset=utf-8\r\n")
					TEXT("Access-Control-Allow-Origin: *\r\n")
					TEXT("Content-Length: %d\r\n")
					TEXT("Connection: close\r\n\r\n%s"),
					ResponseBody.Len(),
					*ResponseBody
				);
			}
		}

		return TEXT("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n{\"error\": \"Malformed JSON-RPC request\"}");
	}

	return TEXT("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");
}

TSharedPtr<FJsonObject> FJagPilotServer::ProcessJsonRpc(const TSharedPtr<FJsonObject>& RequestObj)
{
	TSharedPtr<FJsonObject> Response = MakeShared<FJsonObject>();
	Response->SetStringField(TEXT("jsonrpc"), TEXT("2.0"));

	// Retain request ID
	if (RequestObj->HasField(TEXT("id")))
	{
		Response->SetField(TEXT("id"), RequestObj->TryGetField(TEXT("id")));
	}
	else
	{
		Response->SetNumberField(TEXT("id"), 1);
	}

	FString Method = RequestObj->GetStringField(TEXT("method"));

	// 1. MCP initialize
	if (Method == TEXT("initialize"))
	{
		TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
		Result->SetStringField(TEXT("protocolVersion"), TEXT("2024-11-05"));

		TSharedPtr<FJsonObject> ServerInfo = MakeShared<FJsonObject>();
		ServerInfo->SetStringField(TEXT("name"), TEXT("JagPilot"));
		ServerInfo->SetStringField(TEXT("version"), TEXT("1.0.0"));
		Result->SetObjectField(TEXT("serverInfo"), ServerInfo);

		TSharedPtr<FJsonObject> Capabilities = MakeShared<FJsonObject>();
		Capabilities->SetObjectField(TEXT("tools"), MakeShared<FJsonObject>());
		Capabilities->SetObjectField(TEXT("resources"), MakeShared<FJsonObject>());
		Result->SetObjectField(TEXT("capabilities"), Capabilities);

		Response->SetObjectField(TEXT("result"), Result);
		return Response;
	}

	// 2. notifications/initialized
	if (Method == TEXT("notifications/initialized"))
	{
		Response->SetObjectField(TEXT("result"), MakeShared<FJsonObject>());
		return Response;
	}

	// 3. tools/list
	if (Method == TEXT("tools/list"))
	{
		if (ToolRegistry.IsValid())
		{
			Response->SetObjectField(TEXT("result"), ToolRegistry->GenerateMCPToolsList());
		}
		else
		{
			TSharedPtr<FJsonObject> EmptyResult = MakeShared<FJsonObject>();
			EmptyResult->SetArrayField(TEXT("tools"), TArray<TSharedPtr<FJsonValue>>());
			Response->SetObjectField(TEXT("result"), EmptyResult);
		}
		return Response;
	}

	// 4. tools/call
	if (Method == TEXT("tools/call"))
	{
		const TSharedPtr<FJsonObject>* ParamsObj = nullptr;
		if (RequestObj->TryGetObjectField(TEXT("params"), ParamsObj) && ParamsObj)
		{
			FString ToolName = (*ParamsObj)->GetStringField(TEXT("name"));
			TSharedPtr<FJsonObject> Args;
			const TSharedPtr<FJsonObject>* FoundArgs = nullptr;
			if ((*ParamsObj)->TryGetObjectField(TEXT("arguments"), FoundArgs) && FoundArgs)
			{
				Args = *FoundArgs;
			}
			else
			{
				Args = MakeShared<FJsonObject>();
			}

			// Execute tool safely on GameThread with FScopedTransaction
			TSharedPtr<TPromise<TSharedPtr<FJsonObject>>> Promise = MakeShared<TPromise<TSharedPtr<FJsonObject>>>();

			AsyncTask(ENamedThreads::GameThread, [this, ToolName, Args, Promise]()
			{
				if (ToolRegistry.IsValid())
				{
					TSharedPtr<FJsonObject> ToolResult = ToolRegistry->ExecuteTool(ToolName, Args);
					Promise->SetValue(ToolResult);
				}
				else
				{
					TSharedPtr<FJsonObject> Err = MakeShared<FJsonObject>();
					Err->SetBoolField(TEXT("success"), false);
					Err->SetStringField(TEXT("error"), TEXT("ToolRegistry is not valid."));
					Promise->SetValue(Err);
				}
			});

			TFuture<TSharedPtr<FJsonObject>> Future = Promise->GetFuture();
			// Wait up to 30 seconds for tool completion
			if (Future.WaitFor(FTimespan::FromSeconds(30.0)))
			{
				TSharedPtr<FJsonObject> ExecutionResult = Future.Get();

				FString ResultText;
				TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&ResultText);
				FJsonSerializer::Serialize(ExecutionResult.ToSharedRef(), Writer);

				TSharedPtr<FJsonObject> ContentItem = MakeShared<FJsonObject>();
				ContentItem->SetStringField(TEXT("type"), TEXT("text"));
				ContentItem->SetStringField(TEXT("text"), ResultText);

				TArray<TSharedPtr<FJsonValue>> ContentArray;
				ContentArray.Add(MakeShared<FJsonValueObject>(ContentItem));

				TSharedPtr<FJsonObject> Result = MakeShared<FJsonObject>();
				Result->SetArrayField(TEXT("content"), ContentArray);
				Result->SetBoolField(TEXT("isError"), ExecutionResult->HasField(TEXT("error")));

				Response->SetObjectField(TEXT("result"), Result);
				return Response;
			}
			else
			{
				TSharedPtr<FJsonObject> ErrorObj = MakeShared<FJsonObject>();
				ErrorObj->SetNumberField(TEXT("code"), -32603);
				ErrorObj->SetStringField(TEXT("message"), TEXT("Tool execution timed out on GameThread."));
				Response->SetObjectField(TEXT("error"), ErrorObj);
				return Response;
			}
		}
	}

	// Unknown method error
	TSharedPtr<FJsonObject> ErrorObj = MakeShared<FJsonObject>();
	ErrorObj->SetNumberField(TEXT("code"), -32601);
	ErrorObj->SetStringField(TEXT("message"), FString::Printf(TEXT("Method '%s' not recognized by JagPilot MCP Server."), *Method));
	Response->SetObjectField(TEXT("error"), ErrorObj);
	return Response;
}

