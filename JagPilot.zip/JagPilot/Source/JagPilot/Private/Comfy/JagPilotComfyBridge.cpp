// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "Comfy/JagPilotComfyBridge.h"
#include "JagPilot.h"
#include "JagPilotSettings.h"
#include "JagPilotSubsystem.h"
#include "WebSocketsModule.h"
#include "HttpModule.h"
#include "Interfaces/IHttpResponse.h"
#include "Editor.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "Misc/Guid.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "UObject/Package.h"

FString UJagPilotComfyBridge::NormalizeComfyUrl(const FString& InUrl)
{
	FString Url = InUrl;
	if (Url.IsEmpty() || Url == TEXT("http:") || Url == TEXT("http://") || Url == TEXT("https:") || Url == TEXT("https://"))
	{
		Url = TEXT("http://127.0.0.1:8002");
	}
	if (!Url.StartsWith(TEXT("http://")) && !Url.StartsWith(TEXT("https://")))
	{
		Url = TEXT("http://") + Url;
	}
	while (Url.EndsWith(TEXT("/")))
	{
		Url = Url.LeftChop(1);
	}
	return Url;
}

FString UJagPilotComfyBridge::GetBaseUrl() const
{
	const UJagPilotSettings* Settings = GetDefault<UJagPilotSettings>();
	FString Host = Settings ? Settings->ComfyUIHost : TEXT("127.0.0.1");
	int32 Port = Settings ? Settings->ComfyUIPort : 8002;

	return NormalizeComfyUrl(FString::Printf(TEXT("%s:%d"), *Host, Port));
}

UJagPilotComfyBridge::UJagPilotComfyBridge()
	: bIsExecuting(false)
{
	ClientId = FGuid::NewGuid().ToString();
}

void UJagPilotComfyBridge::Initialize()
{
	ConnectWebSocket();
}

void UJagPilotComfyBridge::Shutdown()
{
	if (WebSocket.IsValid())
	{
		WebSocket->Close();
		WebSocket.Reset();
	}

	if (bIsExecuting)
	{
		if (UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr)
		{
			Subsystem->EndGenerativeAITask();
		}
		bIsExecuting = false;
	}

	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotComfyBridge: Disconnected cleanly."));
}

bool UJagPilotComfyBridge::IsConnected() const
{
	return WebSocket.IsValid() && WebSocket->IsConnected();
}

void UJagPilotComfyBridge::ConnectWebSocket()
{
	FString Base = GetBaseUrl();
	FString Proto = TEXT("ws://");

	if (Base.StartsWith(TEXT("http://")))
	{
		Base = Base.RightChop(7);
	}
	else if (Base.StartsWith(TEXT("https://")))
	{
		Base = Base.RightChop(8);
		Proto = TEXT("wss://");
	}

	FString WsUrl = FString::Printf(TEXT("%s%s/ws?clientId=%s"), *Proto, *Base, *ClientId);

	if (!FModuleManager::Get().IsModuleLoaded("WebSockets"))
	{
		FModuleManager::Get().LoadModule("WebSockets");
	}

	WebSocket = FWebSocketsModule::Get().CreateWebSocket(WsUrl);

	WebSocket->OnConnected().AddUObject(this, &UJagPilotComfyBridge::OnWebSocketConnected);
	WebSocket->OnConnectionError().AddUObject(this, &UJagPilotComfyBridge::OnWebSocketError);
	WebSocket->OnClosed().AddUObject(this, &UJagPilotComfyBridge::OnWebSocketClosed);
	WebSocket->OnMessage().AddUObject(this, &UJagPilotComfyBridge::OnWebSocketMessage);

	WebSocket->Connect();
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotComfyBridge: Connecting to ComfyUI at %s..."), *WsUrl);
}

void UJagPilotComfyBridge::OnWebSocketConnected()
{
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotComfyBridge: Connected to ComfyUI (127.0.0.1:8002) successfully!"));
}

void UJagPilotComfyBridge::OnWebSocketError(const FString& Error)
{
	UE_LOG(LogJagPilot, Warning, TEXT("UJagPilotComfyBridge: ComfyUI connection warning: %s"), *Error);
}

void UJagPilotComfyBridge::OnWebSocketClosed(int32 StatusCode, const FString& Reason, bool bWasClean)
{
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotComfyBridge: WebSocket closed (%d: %s)."), StatusCode, *Reason);
}

void UJagPilotComfyBridge::OnWebSocketMessage(const FString& Message)
{
	TSharedPtr<FJsonObject> JsonObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Message);

	if (!FJsonSerializer::Deserialize(Reader, JsonObj) || !JsonObj.IsValid())
	{
		return;
	}

	FString MsgType = JsonObj->GetStringField(TEXT("type"));
	const TSharedPtr<FJsonObject>* DataObj = nullptr;
	JsonObj->TryGetObjectField(TEXT("data"), DataObj);

	if (MsgType == TEXT("progress") && DataObj && (*DataObj).IsValid())
	{
		int32 Value = (*DataObj)->GetIntegerField(TEXT("value"));
		int32 Max = (*DataObj)->GetIntegerField(TEXT("max"));
		ActiveProgressCallback.ExecuteIfBound(Value, Max);
	}
	else if (MsgType == TEXT("executed") && DataObj && (*DataObj).IsValid())
	{
		FString FinishedPromptId = (*DataObj)->GetStringField(TEXT("prompt_id"));
		if (FinishedPromptId == CurrentPromptId)
		{
			// Workflow finished! End VRAM arbitration
			if (UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr)
			{
				Subsystem->EndGenerativeAITask();
			}
			bIsExecuting = false;

			FString OutputFilename = TEXT("");
			const TSharedPtr<FJsonObject>* OutputObj = nullptr;
			if ((*DataObj)->TryGetObjectField(TEXT("output"), OutputObj) && OutputObj)
			{
				const TArray<TSharedPtr<FJsonValue>>* Images = nullptr;
				if ((*OutputObj)->TryGetArrayField(TEXT("images"), Images) && Images && Images->Num() > 0)
				{
					OutputFilename = (*Images)[0]->AsObject()->GetStringField(TEXT("filename"));
				}
			}

			ActiveCompletionCallback.ExecuteIfBound(true, OutputFilename);
		}
	}
}

void UJagPilotComfyBridge::ExecuteWorkflow(
	const TSharedPtr<FJsonObject>& WorkflowJson,
	const FOnComfyWorkflowCompleted& OnComplete,
	const FOnComfyProgressUpdate& OnProgress)
{
	if (bIsExecuting)
	{
		OnComplete.ExecuteIfBound(false, TEXT("Error: Another ComfyUI task is already executing."));
		return;
	}

	FString BaseUrl = GetBaseUrl();

	// 1. Trigger VRAM Arbitrator: Pauses viewport realtime and frees ~2.3GB VRAM
	if (UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr)
	{
		Subsystem->BeginGenerativeAITask();
	}

	bIsExecuting = true;
	ActiveCompletionCallback = OnComplete;
	ActiveProgressCallback = OnProgress;

	// 2. Submit prompt HTTP POST request
	TSharedPtr<FJsonObject> PromptPayload = MakeShared<FJsonObject>();
	PromptPayload->SetObjectField(TEXT("prompt"), WorkflowJson);
	PromptPayload->SetStringField(TEXT("client_id"), ClientId);

	FString Serialized;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Serialized);
	FJsonSerializer::Serialize(PromptPayload.ToSharedRef(), Writer);

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(FString::Printf(TEXT("%s/prompt"), *BaseUrl));
	Request->SetVerb(TEXT("POST"));
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
	Request->SetContentAsString(Serialized);

	Request->OnProcessRequestComplete().BindLambda([this](FHttpRequestPtr Req, FHttpResponsePtr Resp, bool bSuccess)
	{
		if (!bSuccess || !Resp.IsValid() || Resp->GetResponseCode() != 200)
		{
			UE_LOG(LogJagPilot, Error, TEXT("UJagPilotComfyBridge: Failed to post workflow to ComfyUI."));
			if (UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr)
			{
				Subsystem->EndGenerativeAITask();
			}
			bIsExecuting = false;
			ActiveCompletionCallback.ExecuteIfBound(false, TEXT("Failed to submit workflow to ComfyUI."));
			return;
		}

		TSharedPtr<FJsonObject> RespJson;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Resp->GetContentAsString());
		if (FJsonSerializer::Deserialize(Reader, RespJson) && RespJson.IsValid())
		{
			CurrentPromptId = RespJson->GetStringField(TEXT("prompt_id"));
			UE_LOG(LogJagPilot, Log, TEXT("UJagPilotComfyBridge: Workflow queued with prompt_id: %s"), *CurrentPromptId);
		}
	});

	Request->ProcessRequest();
}

void UJagPilotComfyBridge::DownloadAndImportTexture(const FString& Filename, const FString& TargetPackagePath, TFunction<void(UTexture2D*)> OnImported)
{
	FString DownloadUrl = FString::Printf(TEXT("%s/view?filename=%s"), *GetBaseUrl(), *Filename);

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(DownloadUrl);
	Request->SetVerb(TEXT("GET"));

	Request->OnProcessRequestComplete().BindLambda([Filename, TargetPackagePath, OnImported](FHttpRequestPtr Req, FHttpResponsePtr Resp, bool bSuccess)
	{
		if (!bSuccess || !Resp.IsValid() || Resp->GetResponseCode() != 200)
		{
			UE_LOG(LogJagPilot, Error, TEXT("DownloadAndImportTexture: Failed to download %s"), *Filename);
			OnImported(nullptr);
			return;
		}

		const TArray<uint8>& RawData = Resp->GetContent();

		IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>(FName("ImageWrapper"));
		EImageFormat Format = ImageWrapperModule.DetectImageFormat(RawData.GetData(), RawData.Num());
		TSharedPtr<IImageWrapper> ImageWrapper = ImageWrapperModule.CreateImageWrapper(Format);

		if (!ImageWrapper.IsValid() || !ImageWrapper->SetCompressed(RawData.GetData(), RawData.Num()))
		{
			UE_LOG(LogJagPilot, Error, TEXT("DownloadAndImportTexture: Could not decompress image %s"), *Filename);
			OnImported(nullptr);
			return;
		}

		TArray<uint8> UncompressedRGBA;
		if (!ImageWrapper->GetRaw(ERGBFormat::BGRA, 8, UncompressedRGBA))
		{
			UE_LOG(LogJagPilot, Error, TEXT("DownloadAndImportTexture: Failed to get raw BGRA bytes"));
			OnImported(nullptr);
			return;
		}

		FString PackagePath = TargetPackagePath.IsEmpty() ? FString::Printf(TEXT("/Game/Generated/Textures/%s"), *FPaths::GetBaseFilename(Filename)) : TargetPackagePath;
		UPackage* Package = CreatePackage(*PackagePath);
		Package->FullyLoad();

		UTexture2D* NewTexture = NewObject<UTexture2D>(Package, *FPaths::GetBaseFilename(Filename), RF_Public | RF_Standalone);
		NewTexture->SetPlatformData(new FTexturePlatformData());
		NewTexture->GetPlatformData()->SizeX = ImageWrapper->GetWidth();
		NewTexture->GetPlatformData()->SizeY = ImageWrapper->GetHeight();
		NewTexture->GetPlatformData()->PixelFormat = PF_B8G8R8A8;

		FTexture2DMipMap* Mip = new FTexture2DMipMap();
		NewTexture->GetPlatformData()->Mips.Add(Mip);
		Mip->SizeX = ImageWrapper->GetWidth();
		Mip->SizeY = ImageWrapper->GetHeight();
		Mip->BulkData.Lock(LOCK_READ_WRITE);
		void* TextureData = Mip->BulkData.Realloc(UncompressedRGBA.Num());
		FMemory::Memcpy(TextureData, UncompressedRGBA.GetData(), UncompressedRGBA.Num());
		Mip->BulkData.Unlock();

		NewTexture->Source.Init(ImageWrapper->GetWidth(), ImageWrapper->GetHeight(), 1, 1, TSF_BGRA8, UncompressedRGBA.GetData());
		NewTexture->UpdateResource();
		Package->MarkPackageDirty();

		UE_LOG(LogJagPilot, Log, TEXT("DownloadAndImportTexture: Successfully created UTexture2D at %s"), *PackagePath);
		OnImported(NewTexture);
	});

	Request->ProcessRequest();
}

void UJagPilotComfyBridge::Generate3DMesh(const FString& Prompt, int32 TriangleBudget, const FOnComfyWorkflowCompleted& OnComplete)
{
	// Trellis 2 INT8 + Hunyuan3D v2.1 workflow template
	TSharedPtr<FJsonObject> Workflow = MakeShared<FJsonObject>();

	TSharedPtr<FJsonObject> TextNode = MakeShared<FJsonObject>();
	TextNode->SetStringField(TEXT("class_type"), TEXT("CLIPTextEncode"));
	TSharedPtr<FJsonObject> Inputs = MakeShared<FJsonObject>();
	Inputs->SetStringField(TEXT("text"), Prompt);
	TextNode->SetObjectField(TEXT("inputs"), Inputs);
	Workflow->SetObjectField(TEXT("1"), TextNode);

	ExecuteWorkflow(Workflow, OnComplete);
}

void UJagPilotComfyBridge::GeneratePBRTextures(const FString& InputImageOrPrompt, const FOnComfyWorkflowCompleted& OnComplete)
{
	// MoGe 2 Vit-L Normal + BiRefNet workflow
	TSharedPtr<FJsonObject> Workflow = MakeShared<FJsonObject>();
	ExecuteWorkflow(Workflow, OnComplete);
}

void UJagPilotComfyBridge::GenerateSoundEffect(const FString& AudioPrompt, float DurationSeconds, const FOnComfyWorkflowCompleted& OnComplete)
{
	// Stable Audio Open 1.0 + T5-Base workflow
	TSharedPtr<FJsonObject> Workflow = MakeShared<FJsonObject>();
	ExecuteWorkflow(Workflow, OnComplete);
}
