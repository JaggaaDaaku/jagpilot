// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilotSubsystem.h"
#include "JagPilot.h"
#include "JagPilotSettings.h"
#include "JagPilotToolRegistry.h"
#include "Server/JagPilotServer.h"
#include "AI/JagPilotModelRouter.h"
#include "Comfy/JagPilotComfyBridge.h"
#include "Editor.h"
#include "LevelEditorViewport.h"

UJagPilotSubsystem::UJagPilotSubsystem()
	: ToolRegistry(nullptr)
	, ModelRouter(nullptr)
	, ComfyBridge(nullptr)
	, bIsInitialized(false)
	, bIsGenerativeTaskActive(false)
	, bPreviousViewportRealtimeState(true)
{
}

void UJagPilotSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	// 1. Initialize Tool Registry and register default MCP toolset
	ToolRegistry = NewObject<UJagPilotToolRegistry>(this, TEXT("JagPilotToolRegistry"));
	ToolRegistry->InitializeDefaultTools();

	// 2. Initialize Model Router
	ModelRouter = NewObject<UJagPilotModelRouter>(this, TEXT("JagPilotModelRouter"));
	ModelRouter->Initialize(ToolRegistry);

	// 3. Initialize ComfyUI Bridge
	ComfyBridge = NewObject<UJagPilotComfyBridge>(this, TEXT("JagPilotComfyBridge"));
	ComfyBridge->Initialize();

	// 4. Auto-start in-engine MCP Server if enabled in Settings
	const UJagPilotSettings* Settings = GetDefault<UJagPilotSettings>();
	if (Settings && Settings->bAutoStartServer)
	{
		StartMCPServer();
	}

	bIsInitialized = true;
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotSubsystem Initialized. VRAM Arbitrator & MCP Server ready."));
}

void UJagPilotSubsystem::Deinitialize()
{
	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotSubsystem Deinitializing. Safe teardown starting..."));

	// 1. Stop background server first to avoid socket callbacks into dying UObjects
	StopMCPServer();

	// 2. Disconnect ComfyUI WebSocket
	if (ComfyBridge)
	{
		ComfyBridge->Shutdown();
		ComfyBridge = nullptr;
	}

	// 3. Restore viewport if generative task was interrupted
	if (bIsGenerativeTaskActive)
	{
		EndGenerativeAITask();
	}

	ModelRouter = nullptr;
	ToolRegistry = nullptr;

	bIsInitialized = false;
	Super::Deinitialize();

	UE_LOG(LogJagPilot, Log, TEXT("UJagPilotSubsystem Deinitialized cleanly without UObject leaks."));
}

bool UJagPilotSubsystem::StartMCPServer()
{
	if (MCPServer.IsValid() && MCPServer->IsRunning())
	{
		return true;
	}

	const UJagPilotSettings* Settings = GetDefault<UJagPilotSettings>();
	int32 Port = Settings ? Settings->ServerPort : 8008;

	MCPServer = MakeShared<FJagPilotServer>(Port, ToolRegistry);
	return MCPServer->Start();
}

void UJagPilotSubsystem::StopMCPServer()
{
	if (MCPServer.IsValid())
	{
		MCPServer->StopServer();
		MCPServer.Reset();
	}
}

void UJagPilotSubsystem::BeginGenerativeAITask()
{
	if (bIsGenerativeTaskActive)
	{
		return;
	}

	bIsGenerativeTaskActive = true;

	// 1. Throttle Viewport Realtime Rendering to free GPU compute and memory
	if (FLevelEditorViewportClient* ViewportClient = GetActiveLevelViewportClient())
	{
		bPreviousViewportRealtimeState = ViewportClient->IsRealtime();
		if (bPreviousViewportRealtimeState)
		{
			ViewportClient->SetRealtime(false);
			UE_LOG(LogJagPilot, Log, TEXT("VRAM Arbitrator: Paused active viewport realtime rendering."));
		}
	}

	// 2. Trim memory caches
	if (GEngine)
	{
		GEngine->TrimMemory();
		UE_LOG(LogJagPilot, Log, TEXT("VRAM Arbitrator: GEngine memory trimmed. ~2.3GB VRAM released for ComfyUI."));
	}
}

void UJagPilotSubsystem::EndGenerativeAITask()
{
	if (!bIsGenerativeTaskActive)
	{
		return;
	}

	// Restore previous viewport realtime state
	if (FLevelEditorViewportClient* ViewportClient = GetActiveLevelViewportClient())
	{
		if (bPreviousViewportRealtimeState)
		{
			ViewportClient->SetRealtime(true);
			UE_LOG(LogJagPilot, Log, TEXT("VRAM Arbitrator: Restored active viewport realtime rendering."));
		}
	}

	bIsGenerativeTaskActive = false;
	UE_LOG(LogJagPilot, Log, TEXT("VRAM Arbitrator: Generative task completed. Normal editor state resumed."));
}

FLevelEditorViewportClient* UJagPilotSubsystem::GetActiveLevelViewportClient() const
{
	if (!GEditor)
	{
		return nullptr;
	}

	return static_cast<FLevelEditorViewportClient*>(GEditor->GetActiveViewport() ? GEditor->GetActiveViewport()->GetClient() : nullptr);
}
