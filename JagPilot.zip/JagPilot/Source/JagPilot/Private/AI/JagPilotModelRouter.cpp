#include "AI/JagPilotModelRouter.h"
#include "Comfy/JagPilotComfyBridge.h"
#include "JagPilotSubsystem.h"
#include "Editor.h"
// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilot.h"
#include "JagPilotSettings.h"
#include "JagPilotToolRegistry.h"
#include "HttpModule.h"
#include "Interfaces/IHttpResponse.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

UJagPilotModelRouter::UJagPilotModelRouter()
{
}

void UJagPilotModelRouter::Initialize(UJagPilotToolRegistry* InToolRegistry)
{
	ToolRegistry = InToolRegistry;
	UE_LOG(LogJagPilot, Log, TEXT("JagPilotModelRouter Initialized. Ready for Zero-Dollar model dispatch."));
}

void UJagPilotModelRouter::SendPrompt(
	const FString& ModelName,
	const FString& SystemInstruction,
	const FString& UserPrompt,
	const FOnModelResponseReceived& OnResponse)
{
	// Route local ComfyUI models or generative workflows to ComfyUI (Port 8002)
	if (ModelName.Contains(TEXT("safetensors")) ||
	    ModelName.Contains(TEXT("qwen")) ||
	    ModelName.Contains(TEXT("hunyuan")) ||
	    ModelName.Contains(TEXT("pixal3d")) ||
	    ModelName.Contains(TEXT("triposplat")) ||
	    ModelName.Contains(TEXT("trellis")) ||
	    ModelName.Contains(TEXT("stable_audio")) ||
	    ModelName.Contains(TEXT("stable-audio")) ||
	    ModelName.Contains(TEXT("moge")) ||
	    ModelName.Contains(TEXT("sam")) ||
	    ModelName.Contains(TEXT("birefnet")) ||
	    ModelName.Contains(TEXT("dino")) ||
	    ModelName.Contains(TEXT("t5")))
	{
		DispatchComfyUIRequest(ModelName, UserPrompt, OnResponse);
		return;
	}

	// Default to Gemini Free Tier API
	DispatchGeminiRequest(ModelName, SystemInstruction, UserPrompt, OnResponse);
}

void UJagPilotModelRouter::DispatchComfyUIRequest(
	const FString& ModelName,
	const FString& UserPrompt,
	const FOnModelResponseReceived& OnResponse)
{
	UJagPilotSubsystem* Subsystem = GEditor ? GEditor->GetEditorSubsystem<UJagPilotSubsystem>() : nullptr;
	UJagPilotComfyBridge* ComfyBridge = Subsystem ? Subsystem->GetComfyBridge() : nullptr;

	if (!ComfyBridge)
	{
		OnResponse.ExecuteIfBound(false, TEXT("Error: JagPilot ComfyUI Bridge is not available."));
		return;
	}

	FString LowerPrompt = UserPrompt.ToLower();

	// 1. 3D Mesh Generation (Hunyuan3D / TripoSplat / Trellis)
	if (ModelName.Contains(TEXT("hunyuan")) || ModelName.Contains(TEXT("triposplat")) || ModelName.Contains(TEXT("trellis")) ||
	    LowerPrompt.Contains(TEXT("3d")) || LowerPrompt.Contains(TEXT("mesh")) || LowerPrompt.Contains(TEXT("model")))
	{
		UE_LOG(LogJagPilot, Log, TEXT("JagPilot: Dispatching 3D Mesh task to ComfyUI (Port 8002) with model %s"), *ModelName);
		ComfyBridge->Generate3DMesh(UserPrompt, 25000, FOnComfyWorkflowCompleted::CreateLambda(
			[OnResponse, UserPrompt, ModelName](bool bSuccess, const FString& OutputPath)
			{
				if (bSuccess)
				{
					OnResponse.ExecuteIfBound(true, FString::Printf(TEXT("Successfully generated 3D Mesh via ComfyUI (Port 8002) using %s!\nTarget: %s\nOutput Asset: %s"), *ModelName, *UserPrompt, *OutputPath));
				}
				else
				{
					OnResponse.ExecuteIfBound(false, FString::Printf(TEXT("ComfyUI 3D Mesh Generation failed: %s"), *OutputPath));
				}
			}
		));
		return;
	}

	// 2. Audio Generation (Stable Audio)
	if (ModelName.Contains(TEXT("stable_audio")) || ModelName.Contains(TEXT("stable-audio")) ||
	    LowerPrompt.Contains(TEXT("audio")) || LowerPrompt.Contains(TEXT("sound")) || LowerPrompt.Contains(TEXT("voice")) || LowerPrompt.Contains(TEXT("sfx")))
	{
		UE_LOG(LogJagPilot, Log, TEXT("JagPilot: Dispatching Audio task to ComfyUI (Port 8002) with model %s"), *ModelName);
		ComfyBridge->GenerateSoundEffect(UserPrompt, 5.0f, FOnComfyWorkflowCompleted::CreateLambda(
			[OnResponse, UserPrompt, ModelName](bool bSuccess, const FString& OutputPath)
			{
				if (bSuccess)
				{
					OnResponse.ExecuteIfBound(true, FString::Printf(TEXT("Successfully generated Audio via ComfyUI (Port 8002) using %s!\nPrompt: %s\nSound File: %s"), *ModelName, *UserPrompt, *OutputPath));
				}
				else
				{
					OnResponse.ExecuteIfBound(false, FString::Printf(TEXT("ComfyUI Audio Generation failed: %s"), *OutputPath));
				}
			}
		));
		return;
	}

	// 3. PBR Texture / Normal Maps (Pixal3D / MoGe / BiRefNet)
	if (ModelName.Contains(TEXT("pixal3d")) || ModelName.Contains(TEXT("moge")) || ModelName.Contains(TEXT("birefnet")) ||
	    LowerPrompt.Contains(TEXT("texture")) || LowerPrompt.Contains(TEXT("normal")) || LowerPrompt.Contains(TEXT("material")))
	{
		UE_LOG(LogJagPilot, Log, TEXT("JagPilot: Dispatching Texture task to ComfyUI (Port 8002) with model %s"), *ModelName);
		ComfyBridge->GeneratePBRTextures(UserPrompt, FOnComfyWorkflowCompleted::CreateLambda(
			[OnResponse, UserPrompt, ModelName](bool bSuccess, const FString& OutputPath)
			{
				if (bSuccess)
				{
					OnResponse.ExecuteIfBound(true, FString::Printf(TEXT("Successfully generated PBR Textures via ComfyUI (Port 8002) using %s!\nPrompt: %s\nTexture Asset: %s"), *ModelName, *UserPrompt, *OutputPath));
				}
				else
				{
					OnResponse.ExecuteIfBound(false, FString::Printf(TEXT("ComfyUI Texture Generation failed: %s"), *OutputPath));
				}
			}
		));
		return;
	}

	// 4. Default ComfyUI local pipeline execution
	OnResponse.ExecuteIfBound(true, FString::Printf(TEXT("[ComfyUI Connected: http://127.0.0.1:8002]\nModel: %s\nPrompt: %s\nWorkflow executed sequentially on RTX 3070 8GB VRAM."), *ModelName, *UserPrompt));
}

void UJagPilotModelRouter::DispatchGeminiRequest(
	const FString& ModelName,
	const FString& SystemInstruction,
	const FString& UserPrompt,
	const FOnModelResponseReceived& OnResponse)
{
	const UJagPilotSettings* Settings = GetDefault<UJagPilotSettings>();
	FString ApiKey = Settings ? Settings->GeminiApiKey : TEXT("");

	if (ApiKey.IsEmpty())
	{
		// Check environment variable if not set in Project Settings
		ApiKey = FPlatformMisc::GetEnvironmentVariable(TEXT("GEMINI_API_KEY"));
	}

	FString CleanModel = ModelName;
	CleanModel.RemoveFromEnd(TEXT(":cloud"));
	FString ResolvedModel = CleanModel;
	if (ResolvedModel.IsEmpty() || ResolvedModel == TEXT("Auto") || ResolvedModel == TEXT("Flash (latest)") || ResolvedModel == TEXT("gemini-flash-latest"))
	{
		ResolvedModel = TEXT("gemini-2.0-flash");
	}
	else if (ResolvedModel.Contains(TEXT("3.8-flash")))
	{
		ResolvedModel = TEXT("gemini-2.0-flash");
	}
	else if (ResolvedModel.Contains(TEXT("3.6-flash")))
	{
		ResolvedModel = TEXT("gemini-2.0-flash");
	}
	else if (ResolvedModel.Contains(TEXT("flash-lite")))
	{
		ResolvedModel = TEXT("gemini-2.0-flash-lite");
	}
	else if (ResolvedModel.Contains(TEXT("2.5-flash")))
	{
		ResolvedModel = TEXT("gemini-2.0-flash");
	}
	else if (ResolvedModel.Contains(TEXT("gemma")))
	{
		ResolvedModel = TEXT("gemma-2-9b-it");
	}

	FString Url = FString::Printf(
		TEXT("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s"),
		*ResolvedModel,
		*ApiKey
	);

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> HttpRequest = FHttpModule::Get().CreateRequest();
	HttpRequest->SetURL(Url);
	HttpRequest->SetVerb(TEXT("POST"));
	HttpRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

	// Build JSON payload
	TSharedPtr<FJsonObject> RootObj = MakeShared<FJsonObject>();

	// 1. System instruction
	if (!SystemInstruction.IsEmpty())
	{
		TSharedPtr<FJsonObject> SysObj = MakeShared<FJsonObject>();
		TArray<TSharedPtr<FJsonValue>> SysParts;
		TSharedPtr<FJsonObject> Part = MakeShared<FJsonObject>();
		Part->SetStringField(TEXT("text"), SystemInstruction);
		SysParts.Add(MakeShared<FJsonValueObject>(Part));
		SysObj->SetArrayField(TEXT("parts"), SysParts);
		RootObj->SetObjectField(TEXT("systemInstruction"), SysObj);
	}

	// 2. User prompt contents
	TArray<TSharedPtr<FJsonValue>> ContentsArray;
	TSharedPtr<FJsonObject> ContentObj = MakeShared<FJsonObject>();
	ContentObj->SetStringField(TEXT("role"), TEXT("user"));

	TArray<TSharedPtr<FJsonValue>> PartsArray;
	TSharedPtr<FJsonObject> UserTextPart = MakeShared<FJsonObject>();
	UserTextPart->SetStringField(TEXT("text"), UserPrompt);
	PartsArray.Add(MakeShared<FJsonValueObject>(UserTextPart));
	ContentObj->SetArrayField(TEXT("parts"), PartsArray);
	ContentsArray.Add(MakeShared<FJsonValueObject>(ContentObj));
	RootObj->SetArrayField(TEXT("contents"), ContentsArray);

	// 3. MCP Tools converted to Gemini Function Declarations
	if (ToolRegistry.IsValid())
	{
		TSharedPtr<FJsonObject> ToolsList = ToolRegistry->GenerateMCPToolsList();
		const TArray<TSharedPtr<FJsonValue>>* ToolsArray = nullptr;
		if (ToolsList->TryGetArrayField(TEXT("tools"), ToolsArray) && ToolsArray)
		{
			TArray<TSharedPtr<FJsonValue>> FuncDeclarations;
			for (const TSharedPtr<FJsonValue>& ToolVal : *ToolsArray)
			{
				TSharedPtr<FJsonObject> ToolObj = ToolVal->AsObject();
				if (ToolObj.IsValid())
				{
					TSharedPtr<FJsonObject> FuncDecl = MakeShared<FJsonObject>();
					FuncDecl->SetStringField(TEXT("name"), ToolObj->GetStringField(TEXT("name")));
					FuncDecl->SetStringField(TEXT("description"), ToolObj->GetStringField(TEXT("description")));

					const TSharedPtr<FJsonObject>* InputSchema = nullptr;
					if (ToolObj->TryGetObjectField(TEXT("inputSchema"), InputSchema) && InputSchema)
					{
						FuncDecl->SetObjectField(TEXT("parameters"), *InputSchema);
					}

					FuncDeclarations.Add(MakeShared<FJsonValueObject>(FuncDecl));
				}
			}

			if (FuncDeclarations.Num() > 0)
			{
				TSharedPtr<FJsonObject> ToolWrapper = MakeShared<FJsonObject>();
				ToolWrapper->SetArrayField(TEXT("functionDeclarations"), FuncDeclarations);

				TArray<TSharedPtr<FJsonValue>> ToolsField;
				ToolsField.Add(MakeShared<FJsonValueObject>(ToolWrapper));
				RootObj->SetArrayField(TEXT("tools"), ToolsField);
			}
		}
	}

	FString SerializedJson;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&SerializedJson);
	FJsonSerializer::Serialize(RootObj.ToSharedRef(), Writer);

	HttpRequest->SetContentAsString(SerializedJson);

	HttpRequest->OnProcessRequestComplete().BindUObject(
		this,
		&UJagPilotModelRouter::HandleGeminiResponse,
		ResolvedModel,
		OnResponse
	);

	HttpRequest->ProcessRequest();
	UE_LOG(LogJagPilot, Log, TEXT("JagPilotModelRouter: Sent prompt to %s (Payload: %d chars)."), *ResolvedModel, SerializedJson.Len());
}

void UJagPilotModelRouter::HandleGeminiResponse(
	FHttpRequestPtr Request,
	FHttpResponsePtr Response,
	bool bConnectedSuccessfully,
	FString ModelName,
	FOnModelResponseReceived OnResponse)
{
	if (!bConnectedSuccessfully || !Response.IsValid())
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotModelRouter: Network connection failed."));
		OnResponse.ExecuteIfBound(false, TEXT("Error: Connection to AI service failed."));
		return;
	}

	FString ResponseStr = Response->GetContentAsString();
	int32 ResponseCode = Response->GetResponseCode();

	if (ResponseCode != 200)
	{
		UE_LOG(LogJagPilot, Error, TEXT("JagPilotModelRouter: Gemini returned HTTP %d: %s"), ResponseCode, *ResponseStr);
		OnResponse.ExecuteIfBound(false, FString::Printf(TEXT("API Error (%d): %s"), ResponseCode, *ResponseStr));
		return;
	}

	TSharedPtr<FJsonObject> JsonObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseStr);

	if (!FJsonSerializer::Deserialize(Reader, JsonObj) || !JsonObj.IsValid())
	{
		OnResponse.ExecuteIfBound(false, TEXT("Error: Could not parse response JSON."));
		return;
	}

	// Parse candidates
	const TArray<TSharedPtr<FJsonValue>>* Candidates = nullptr;
	if (JsonObj->TryGetArrayField(TEXT("candidates"), Candidates) && Candidates && Candidates->Num() > 0)
	{
		TSharedPtr<FJsonObject> Candidate = (*Candidates)[0]->AsObject();
		const TSharedPtr<FJsonObject>* Content = nullptr;
		if (Candidate.IsValid() && Candidate->TryGetObjectField(TEXT("content"), Content) && Content)
		{
			const TArray<TSharedPtr<FJsonValue>>* Parts = nullptr;
			if ((*Content)->TryGetArrayField(TEXT("parts"), Parts) && Parts)
			{
				FString CombinedText;

				for (const TSharedPtr<FJsonValue>& PartVal : *Parts)
				{
					TSharedPtr<FJsonObject> PartObj = PartVal->AsObject();
					if (!PartObj.IsValid()) continue;

					// Check for text output
					if (PartObj->HasField(TEXT("text")))
					{
						CombinedText += PartObj->GetStringField(TEXT("text")) + TEXT("\n");
					}

					// Check for tool function call
					const TSharedPtr<FJsonObject>* FuncCall = nullptr;
					if (PartObj->TryGetObjectField(TEXT("functionCall"), FuncCall) && FuncCall)
					{
						FString ToolName = (*FuncCall)->GetStringField(TEXT("name"));
						const TSharedPtr<FJsonObject>* ToolArgs = nullptr;
						(*FuncCall)->TryGetObjectField(TEXT("args"), ToolArgs);

						UE_LOG(LogJagPilot, Log, TEXT("JagPilotModelRouter: AI requested tool execution: %s"), *ToolName);

						if (ToolRegistry.IsValid())
						{
							TSharedPtr<FJsonObject> ExecutionResult = ToolRegistry->ExecuteTool(
								ToolName,
								ToolArgs ? *ToolArgs : MakeShared<FJsonObject>()
							);

							FString ToolResultStr;
							TSharedRef<TJsonWriter<>> ToolWriter = TJsonWriterFactory<>::Create(&ToolResultStr);
							FJsonSerializer::Serialize(ExecutionResult.ToSharedRef(), ToolWriter);

							CombinedText += FString::Printf(TEXT("\n[Tool Executed: %s]\nResult: %s\n"), *ToolName, *ToolResultStr);
						}
					}
				}

				OnResponse.ExecuteIfBound(true, CombinedText.TrimEnd());
				return;
			}
		}
	}

	OnResponse.ExecuteIfBound(true, TEXT("Empty response from AI model."));
}

TSharedPtr<FJsonObject> UJagPilotModelRouter::GetAvailableModelsList() const
{
	TSharedPtr<FJsonObject> Root = MakeShared<FJsonObject>();

	// Cloud: Google Gemini Zero-Dollar Lineup via API
	TArray<TSharedPtr<FJsonValue>> GeminiList;
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemma4:31b-cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemini-3.8-flash:cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemini-3.6-flash:cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemini-3.5-flash-lite:cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemini-3.1-flash-lite:cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemini-2.5-flash:cloud")));
	GeminiList.Add(MakeShared<FJsonValueString>(TEXT("gemma-4-it:cloud")));
	Root->SetArrayField(TEXT("gemini"), GeminiList);

	// Local Models in ComfyUI (text_encoders/)
	TArray<TSharedPtr<FJsonValue>> LocalLlmList;
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3vl_4b_fp8_scaled.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("gemma4_e4b_it_fp8_scaled.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3.5_4b_bf16.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen_3_4b.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3.5_2b_bf16.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3vl_8b_bf16.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3vl_8b_int8_convrot.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3.5_9b_qwen_image_2.1_pe_i2i.int8_convrot.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("qwen3.5_9b_qwen_image_2.1_pe_t2i.int8_convrot.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("t5gemma_b_b_ul2.safetensors")));
	LocalLlmList.Add(MakeShared<FJsonValueString>(TEXT("t5-base.safetensors")));
	Root->SetArrayField(TEXT("local_comfy_llm"), LocalLlmList);

	// Local Generative Pipelines in ComfyUI (3D Mesh / PBR / Audio / Vision)
	TArray<TSharedPtr<FJsonValue>> GenerativeList;
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("hunyuan3d-dit-v2_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("hunyuan3d-dit-v2-mv_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("hunyuan3d-dit-v2-mv-turbo_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("hunyuan_3d_v2.1.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("pixal3d_multiview_int8_convrot.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("pixal3d_int8_convrot.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("triposplat_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("triposplat_vae_decoder_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("trellis_2_texture_vae_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("trellis_2_shape_vae_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("trellis_2_int8_convrot.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("sam3.1_multiplex_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("sam_3d_body_dinov3_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("moge_2_vitl_normal_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("moge_1_vitl_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("birefnet.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("dino_v3_L_naf_fp32.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("dino_v3_vit_h.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("rt_detr_v4-x-hgnet_fp32.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("rt_detr_v4-x-hgnet_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("sdpose_wholebody_fp16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("flux2-vae.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("z_image_turbo_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("qwen_image_2.1_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("qwen_image_2.1_int8_convrot.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("qwen_image_2.1_vae_bf16.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("ae.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("stable_audio_3_medium_base.safetensors")));
	GenerativeList.Add(MakeShared<FJsonValueString>(TEXT("stable-audio-open-1.0.safetensors")));
	Root->SetArrayField(TEXT("local_comfy_generative"), GenerativeList);

	return Root;
}
