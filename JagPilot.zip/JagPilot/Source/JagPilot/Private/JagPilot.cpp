// Copyright (c) 2026 Jagga & Antigravity. All Rights Reserved.

#include "JagPilot.h"
#include "UI/JagPilotPanel.h"

DEFINE_LOG_CATEGORY(LogJagPilot);

#define LOCTEXT_NAMESPACE "FJagPilotModule"

void FJagPilotModule::StartupModule()
{
	UE_LOG(LogJagPilot, Log, TEXT("JagPilot Module Started (v1.0.0). Hardware Optimization: 12700H + RTX 3070 8GB VRAM."));
	FJagPilotPanel::RegisterTab();
}

void FJagPilotModule::ShutdownModule()
{
	UE_LOG(LogJagPilot, Log, TEXT("JagPilot Module Shutting Down safely."));
	FJagPilotPanel::UnregisterTab();
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FJagPilotModule, JagPilot)
